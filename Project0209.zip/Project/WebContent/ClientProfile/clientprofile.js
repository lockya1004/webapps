/**
 * 
 */

function CPcheck() {
	
}