package com.project.action.support;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.SupportDAO;
import com.project.dto.SupportVO;

public class SupportUpdateAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	int num=Integer.parseInt(request.getParameter("num"));
	String title=request.getParameter("title");
	String kinds=request.getParameter("kinds");
	String id=request.getParameter("id");
	String pwd=request.getParameter("pwd");
	String email=request.getParameter("email");
	String content=request.getParameter("content");
	
	
	SupportVO vo=new SupportVO();
	vo.setNum(num);
	vo.setTitle(title);
	vo.setKinds(kinds);
	vo.setId(id);
	vo.setPwd(pwd);
	vo.setEmail(email);
	vo.setContent(content);
	SupportDAO sdao=SupportDAO.getinstance();
	sdao.updateSupport(vo);
	
	new SupportListAction().execute(request, response);
	

	}

}
