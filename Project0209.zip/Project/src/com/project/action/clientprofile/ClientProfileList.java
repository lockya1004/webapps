package com.project.action.clientprofile;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.ClientProfileDAO;
import com.project.dao.SupportDAO;
import com.project.dto.ClientProfileVO;
import com.project.dto.SupportVO;

public class ClientProfileList implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//HttpSession session=request.getSession();		
		/*String id=(String) session.getAttribute("id");
		try {
		if(id.equals("null")) {
			response.sendRedirect("/Project/ClientProfile/ClientErrorPage.jsp");
		}else if(id.equals("admin")) {
			String url="/ClientProfile/clientProfileList.jsp";
			ClientProfileDAO cpdao=ClientProfileDAO.getinstance();
			List<ClientProfileVO> list=cpdao.CpList();		
			request.setAttribute("cpList",list);
			//모든 Action은 forward한다.
			RequestDispatcher dispatchar=request.getRequestDispatcher(url);
			dispatchar.forward(request, response);
			
		}
		
		}catch(Exception e) {
			response.sendRedirect("/Project/ClientProfile/ClientErrorPage.jsp");
		}*/
		String url="/ClientProfile/clientProfileList.jsp";
		ClientProfileDAO cpdao=ClientProfileDAO.getinstance();
		List<ClientProfileVO> list=cpdao.CpList();		
		request.setAttribute("cprofilelist",list);
		//모든 Action은 forward한다.
		RequestDispatcher dispatchar=request.getRequestDispatcher(url);
		dispatchar.forward(request, response);
		
		
	}

}
