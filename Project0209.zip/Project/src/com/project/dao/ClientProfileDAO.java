package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.project.dto.ClientProfileVO;
import com.project.dto.SupportVO;
import com.project.util.DBManager;

public class ClientProfileDAO {

	// 싱글톤
	private ClientProfileDAO() {
	}

	private static ClientProfileDAO instance = new ClientProfileDAO();

	public static ClientProfileDAO getinstance() {
		return instance;
	}

	// c

	public void CpWrite(ClientProfileVO cvo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into clientprofile(num, id, name, kinds, address, image) values(cp_seq.nextval,?,?,?,?,?)";
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cvo.getId());
			pstmt.setString(2, cvo.getName());
			pstmt.setString(3, cvo.getKinds());
			pstmt.setString(4, cvo.getAddress());
			pstmt.setString(5, cvo.getImage());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	// r

	public List<ClientProfileVO> CpList() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from clientprofile order by num";
		List<ClientProfileVO> list = new ArrayList<ClientProfileVO>();
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ClientProfileVO vo = new ClientProfileVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setName(rs.getString("name"));
				vo.setAddress(rs.getString("address"));
				vo.setImage(rs.getString("image"));
				vo.setWritedate(rs.getTimestamp("writedate"));
				list.add(vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}
	// view

	public ClientProfileVO selected(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		String sql="select * from  clientprofile where num=?";
		ClientProfileVO cvo = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				cvo=new ClientProfileVO();
				cvo.setNum(rs.getInt("num"));
				cvo.setId(rs.getString("id"));
				cvo.setName(rs.getString("name"));
				cvo.setKinds(rs.getString("kinds"));
				cvo.setAddress(rs.getString("address"));
				cvo.setImage(rs.getString("image"));
				cvo.setWritedate(rs.getTimestamp("writedate"));
				}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		
		return cvo;
	}

	
	

	// u
	
	public void update(ClientProfileVO cpvo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="update clientprofile set name=?,kinds=?,address=?,image=? where num=?";
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cpvo.getName());
			pstmt.setString(2, cpvo.getKinds());
			pstmt.setString(3, cpvo.getAddress());
			System.out.println(cpvo.getImage());
			pstmt.setString(4, cpvo.getImage());
			pstmt.setInt(5, cpvo.getNum());
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	
		
		
	}


	// d
	public void delete(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="delete clientprofile where num=?";
		ClientProfileVO cvo = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {

			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

}
