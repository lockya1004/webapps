package com.project.dao;

import java.util.List;

import com.project.dto.ClientProfileVO;

public class MypageDAO {
	
	// 싱글톤
		private MypageDAO(){
		}

		private static MypageDAO instance = new MypageDAO();

	public static MypageDAO getinstance() {
		// TODO Auto-generated method stub
		return instance;
	}

	//r
	public List<mypage {
	
	
}
