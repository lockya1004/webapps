/**
 * 
 */





function openNav() {
	var click=document.getElementById("sidebtn").value;
	
if(click=="◀"){
		document.getElementById("sidemenu").style.width = "0";
		document.getElementById("sidebtn").value="▶";
	}else {
		 document.getElementById("sidemenu").style.width = "150px";
		 document.getElementById("sidebtn").value="◀";
	}
	
}





function allcheck() {

		$("#sel").click(function() {
			if ($("#sel").is(":checked")) {
				$("input[name=select]:checkbox").attr("checked", true);
			} else {
				$("input[name=select]:checkbox").attr("checked", false);
			}
		});

	}

	
function button(id) {
	 var data=0;
     var id=id;
     
     alert(id);
	 $('input:checkbox[name=select]').each(function() {
	
	     if(this.checked == true){ //값 비교
			if(data==0){
	         data=this.value;
			}else{
			data+=","+this.value;
			}
	      }
	 });
	 location.href="/Project/me.do?command=btn&btnid="+id+"&num="+data;
	 
}

