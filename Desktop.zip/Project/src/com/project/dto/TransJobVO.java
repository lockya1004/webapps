package com.project.dto;

import java.sql.Timestamp;

public class TransJobVO {
	private int jobNum;
	private Timestamp jobRegDate;
	private String jobContent;
	private String agentName;
	private String jobType;
	
	//Getters;
	public int getJobNum() {
		return jobNum;
	}
	public Timestamp getJobRegDate() {
		return jobRegDate;
	}
	public String getJobContent() {
		return jobContent;
	}
	public String getAgentName() {
		return agentName;
	}
	public String getJobType() {
		return jobType;
	}
	
	//Setters;
	public void setJobNum(int jobNum) {
		this.jobNum = jobNum;
	}
	public void setJobRegDate(Timestamp jobRegDate) {
		this.jobRegDate = jobRegDate;
	}
	public void setJobContent(String jobContent) {
		this.jobContent = jobContent;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	
	
}
