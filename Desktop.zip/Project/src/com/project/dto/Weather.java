package com.project.dto;

public class Weather {
	private String day;
	private String location;
	private double temp;
	private String icon;
	
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public double getTemp() {
		return temp;
	}
	public void setTemp(double d) {
		this.temp = d;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	
	
	
}
