package com.project.dto;

public class TransProfileVO {
	
	private int code;
	private String imgUrl;
	private String srcLanguage;
	private String targLanguage;
	private String area;
	private String portfolio;
	private String name;
	private String id;
	private String address;
	private String payRate;
	private String contact;
	private String software;
	
	//Getters;
	
	public int getCode() {
		return code;
	}	
	public String getContact() {
		return contact;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public String getId() {
		return id;
	}	
	public String getImgUrl() {
		return imgUrl;
	}
	public String getSrcLanguage() {
		return srcLanguage;
	}
	public String getTargLanguage() {
		return targLanguage;
	}
	public String getArea() {
		return area;
	}
	public String getPortfolio() {
		return portfolio;
	}
	public String getPayRate() {
		return payRate;
	}	
	
	public String getSoftware() {
		return software;
	}

	//Setters;
	public void setContact(String contact) {
		this.contact = contact;
	}	
	public void setCode(int code) {
		this.code = code;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public void setArea(String area) {
		this.area = area;
	}
	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setId(String id) {
		this.id = id;
	}	
	public void setPayRate(String payRate) {
		this.payRate = payRate;
	}
	public void setSoftware(String software) {
		this.software = software;
	}
	public void setSrcLanguage(String srcLanguage) {
		this.srcLanguage = srcLanguage;
	}
	public void setTargLanguage(String targLanguage) {
		this.targLanguage = targLanguage;
	}
	
}
