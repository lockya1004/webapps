package com.project.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.project.dto.ReVO;
import com.project.util.DBManager;


public class ReDAO {

	private ReDAO() {
		
	}

	private static ReDAO ins = new ReDAO();
	
	public static ReDAO getins() {
		return ins;
	}
		
	

	public void insertRe(ReVO rvo) {
		String sql = "insert into request("
				+ "num, pass, userid, title, SourceLang, TargetLang, content, refile, deadline, cash)"
				+ "values(re_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBManager.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, rvo.getPass());
			pstmt.setString(2, rvo.getUserid());
			pstmt.setString(3, rvo.getTitle());
			pstmt.setString(4, rvo.getSourceLang());
			pstmt.setString(5, rvo.getTargetLang());
			pstmt.setString(6, rvo.getContent());
			pstmt.setString(7, rvo.getRefile());
			java.util.Date date=rvo.getDeadline();
			java.sql.Date sqldate=new Date(date.getTime());
			pstmt.setDate(8, sqldate);
			pstmt.setString(9, rvo.getCash());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(conn, pstmt);
		}
	}
	
	
	
	
	
	public void updateReadCont(int num) {
		String sql = "update request set readcount=readcount+1 where num=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			DBManager.close(conn, pstmt);
		}
	}
	
	
	
	
	
	//寃뚯떆�뙋 湲� �긽�꽭 �궡�슜 蹂닿린 :湲�踰덊샇濡� 李얠븘�삩�떎.: �떎�뙣 null,
	public ReVO selectOneReByNum(int num) {
		String sql = " select r.num, r.pass, m.name, r.userid, m.email, r.title,  r.SourceLang, r.TargetLang, r.content, "
				+ "r.refile, r.deadline,r.cash,r.readcount, r.writedate, r.now" + 
				" from request r, member m where m.userid=r.userid and r.num = ?";
		
		ReVO rvo = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs  = null;
		
		try {
			conn = DBManager.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				rvo = new ReVO();
				
				rvo.setNum(rs.getInt("num"));
				rvo.setPass(rs.getString("pass"));  
				rvo.setName(rs.getString("name"));
				rvo.setUserid(rs.getString("userid"));
				rvo.setEmail(rs.getString("email"));
				rvo.setTitle(rs.getString("title"));
				rvo.setSourceLang(rs.getString("SourceLang"));
				rvo.setTargetLang(rs.getString("TargetLang"));
				rvo.setContent(rs.getString("content"));
				rvo.setRefile(rs.getString("refile"));
				rvo.setDeadline(rs.getTimestamp("deadline"));
				rvo.setCash(rs.getString("cash"));
				rvo.setReadcont(rs.getInt("readcount"));
				rvo.setWrirdate(rs.getTimestamp("writedate"));	
				rvo.setNow(rs.getString("now"));
			}
			
			} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(conn, pstmt, rs);
		}
		return rvo;
	}
	
	
	
	
	
	public void updateRe(ReVO rvo) {
		String sql = "update request set pass=?, title=?, SourceLang=?, TargetLang=?, content=?,"
				+ "reflie=?, deadline=?, cash=?, now=? where num=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, rvo.getPass());
			pstmt.setString(2, rvo.getTitle());
			pstmt.setString(3, rvo.getSourceLang());
			pstmt.setString(4, rvo.getTargetLang());
			pstmt.setString(5, rvo.getContent());
			pstmt.setString(6, rvo.getRefile());
			java.util.Date date=rvo.getDeadline();
			java.sql.Date sqldate=new Date(date.getTime());
		
			pstmt.setDate(7, sqldate);
			pstmt.setString(8, rvo.getCash());
			pstmt.setInt(9, rvo.getNum());
			pstmt.executeQuery();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(conn, pstmt);
		}
	}
	
	
	
	
	
	public ReVO checkPassWord(String pass, String num) {
		String sql = "select r.num, r.pass, m.name, r.userid, m.email, r.title,  r.SourceLang, r.TargetLang, r.content, "
				+ "r.refile, r.deadline,r.cash,r.readcount, r.writedate, r.now"
				+ " from request r, member m where m.userid=r.userid and pass=? and num=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ReVO rvo = null;
		
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, pass);
			pstmt.setString(2, num);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				rvo = new ReVO();
				rvo.setNum(rs.getInt("num"));
				rvo.setPass(rs.getString("pass"));  
				rvo.setName(rs.getString("name"));
				rvo.setUserid(rs.getString("userid"));
				rvo.setEmail(rs.getString("email"));
				rvo.setTitle(rs.getString("title"));
				rvo.setSourceLang(rs.getString("SourceLang"));
				rvo.setTargetLang(rs.getString("TargetLang"));
				rvo.setContent(rs.getString("content"));
				rvo.setRefile(rs.getString("refile"));
				rvo.setDeadline(rs.getTimestamp("deadline"));
				rvo.setCash(rs.getString("cash"));
				rvo.setReadcont(rs.getInt("readcount"));
				rvo.setWrirdate(rs.getTimestamp("writedate"));	
				rvo.setNow(rs.getString("now"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rvo;
	}
	
	
	
	
	
	
	public void deleteRe(String num) {
		String sql = "delete request where num=?";
				
		Connection conn = null;
		PreparedStatement pstmt = null;
				
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, num);
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public List<ReVO> listRe(){ 
		
		List<ReVO> list=new ArrayList<ReVO>();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=DBManager.getConnection();
			String sql="select * from request order by num desc";
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				ReVO vo=new ReVO();
				vo.setNum(rs.getInt("num"));
				vo.setTitle(rs.getString("title"));			
				vo.setSourceLang(rs.getString("SourceLang"));
				vo.setTargetLang(rs.getString("TargetLang"));
				vo.setWrirdate(rs.getTimestamp("writedate"));
				vo.setUserid(rs.getString("userid"));
				vo.setNow(rs.getString("now"));
				list.add(vo);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		
		}finally {
			try {
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		
		
		return list;
		}



	

	
	
}