package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.project.dto.MessageVO;
import com.project.util.DBManager;

public class MessageDao {

	//�떛湲��넠
	
	private MessageDao() {}
	
	private static MessageDao instance=new MessageDao();
	
	public static MessageDao getinstence() {
		return instance;
	}
	
	//쪽지보내기
	public void insert(MessageVO vo) {
		String sql="insert into message(NUM,fromid,toid,content) values(MESSAGE_SEQ.nextval,?,?,?)";
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
		conn=DBManager.getConnection();
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, vo.getFromid());
		pstmt.setString(2, vo.getToid());
		pstmt.setString(3, vo.getContent());
		pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	
	//보낸 쪽지함
	public List<MessageVO> sendmessage(String id) {
	String sql="select num,toid,content,sendtime,readtime from message where fromid=? order by num desc";
	List<MessageVO> list=new ArrayList<MessageVO>();
	Connection conn=null;
	PreparedStatement pstmt=null;
	ResultSet rs=null;
	
	try {
		conn=DBManager.getConnection();
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			MessageVO vo=new MessageVO();
			vo.setNum(rs.getInt("num"));
			vo.setToid(rs.getString("toid"));
			vo.setContent(rs.getString("content"));
			vo.setSendtime(rs.getTimestamp("sendtime"));
			vo.setReadtime(rs.getTimestamp("readtime"));
			list.add(vo);
		}
		
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	return list;
	}
	
	//받은 쪽지함에서 전체.
	public List<MessageVO> sendtome(String id){
	String sql="select num,fromid,content,sendtime from message where toid=? and waste=0 and keep=0 order by num desc";
	List<MessageVO> list=new ArrayList<MessageVO>();
	Connection conn=null;
	PreparedStatement pstmt=null;
	ResultSet rs=null;
	
	try {
		conn=DBManager.getConnection();
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			MessageVO vo=new MessageVO();
			vo.setNum(rs.getInt("num"));
			vo.setFromid(rs.getString("fromid"));
			vo.setContent(rs.getString("content"));
			vo.setSendtime(rs.getTimestamp("sendtime"));
			list.add(vo);
		}
		
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	return list;
	}

	
	//쪽지 내용 보기.
	
	public MessageVO readmessage(int num) {
		MessageVO vo = null;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select * from message where num=?";
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs=pstmt.executeQuery();
		
		if(rs.next()) {
		vo=new MessageVO();
		vo.setNum(rs.getInt("num"));
		vo.setFromid(rs.getString("fromid"));
		vo.setToid(rs.getString("toid"));
		vo.setSendtime(rs.getTimestamp("sendtime"));
		vo.setContent(rs.getString("content"));
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		return vo;
	}
	
	//읽은 시간 표시하기.
	
	public void updateread(int num) {
		String sql="update MESSAGE SET READORNOT = 1, readtime=sysdate where num=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	//읽지 않은 쪽지 개수.
	public int notreadcount(String id) {
		String sql="select count(readornot) from MESSAGE where toid=? and READORNOT=0";
		int count = 0;
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				count=rs.getInt("count(readornot)");
			}
		} catch (Exception e) {
		e.printStackTrace();
		}
			
		return count;
	}
	
	//받은이가 아직 읽지 않은 메세지 =>받은 편지함..
	public List<MessageVO> yetread(String id, String readnot){
		String sql="select num,fromid,content,sendtime from message where toid=? and readornot=?";
		List<MessageVO> list=new ArrayList<MessageVO>();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setInt(2, Integer.parseInt(readnot));
			rs=pstmt.executeQuery();
			while(rs.next()) {
				MessageVO vo=new MessageVO();
				vo.setNum(rs.getInt("num"));
				vo.setFromid(rs.getString("fromid"));
				vo.setContent(rs.getString("content"));
				vo.setSendtime(rs.getTimestamp("sendtime"));
				list.add(vo);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return list;
		}
	
	
	//받은 이가 아직 읽지 않은 쪽지 =>보낸쪽지함
	public List<MessageVO> toyetread(String id, String readnot){
		String sql="select num,toid,content,sendtime from message where fromid=? and readornot=?";
		List<MessageVO> list=new ArrayList<MessageVO>();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setInt(2, Integer.parseInt(readnot));
			rs=pstmt.executeQuery();
			while(rs.next()) {
				MessageVO vo=new MessageVO();
				vo.setNum(rs.getInt("num"));
				vo.setFromid(rs.getString("toid"));
				vo.setContent(rs.getString("content"));
				vo.setSendtime(rs.getTimestamp("sendtime"));
				list.add(vo);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return list;
		}
	
	
	//휴지통으로 이동
	public void updatewaste(int num) {
		String sql="update MESSAGE SET waste = 1 where num=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	
	
	//휴지통으로 이동한 리스트
	public List<MessageVO> list_waste(){
		String sql="select num,fromid,content,sendtime from message where waste=1 and keep=0 order by num desc";
		List<MessageVO> list=new ArrayList<MessageVO>();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				MessageVO vo=new MessageVO();
				vo.setNum(rs.getInt("num"));
				vo.setFromid(rs.getString("fromid"));
				vo.setContent(rs.getString("content"));
				vo.setSendtime(rs.getTimestamp("sendtime"));
				list.add(vo);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return list;
		}

	public void updatekeep(int num) {
		String sql="update MESSAGE SET keep = 1 where num=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}

	//다수, 혹은 소수 쪽지 삭제
	public void messagedelete(int num) {
		String sql="delete from message where num=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}

	//휴지통 비우기
	public void alldelete() {
		String sql="delete from message where waste=1";
		Connection conn=null;
		PreparedStatement pstmt=null;
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		
	}

	public List<MessageVO> list_keep() {
		String sql="select num,fromid,content,sendtime from message where keep=1 and waste=0 order by num desc";
		List<MessageVO> list=new ArrayList<MessageVO>();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				MessageVO vo=new MessageVO();
				vo.setNum(rs.getInt("num"));
				vo.setFromid(rs.getString("fromid"));
				vo.setContent(rs.getString("content"));
				vo.setSendtime(rs.getTimestamp("sendtime"));
				list.add(vo);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		return list;
	}
	
}
