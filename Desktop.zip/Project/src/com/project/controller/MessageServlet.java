package com.project.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.action.MessageFactory;

@WebServlet("/me.do")
public class MessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public MessageServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String command=request.getParameter("command");
		MessageFactory mf=MessageFactory.getinstance();
		Action action=mf.getAction(command);
		if(action != null) {
			action.execute(request, response);	
		}else {
			System.out.println("Message ����");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
