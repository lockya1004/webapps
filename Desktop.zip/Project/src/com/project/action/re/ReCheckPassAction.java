package com.project.action.re;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.ReDAO;
import com.project.dto.ReVO;

public class ReCheckPassAction implements Action {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String url = null;
		
		int num = Integer.parseInt(request.getParameter("num"));
		String pass = request.getParameter("pass");
		
		ReDAO rdao = ReDAO.getins();
		ReVO rvo = rdao.selectOneReByNum(num);
		
		if(rvo.getPass().equals(pass)){ // 성공
			url ="/re/checkSuccess.jsp";
		}else {//실패
			url = "/re/reCheckPass.jsp";
			request.setAttribute("message", "비밀번호가 틀렸습니다");
		}
		RequestDispatcher dis = request.getRequestDispatcher(url);
		dis.forward(request, response);
		
	}
}
