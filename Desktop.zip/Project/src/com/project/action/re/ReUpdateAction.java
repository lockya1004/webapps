package com.project.action.re;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dao.ReDAO;
import com.project.dto.ReVO;

public class ReUpdateAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 request.setCharacterEncoding("utf-8");
	      ServletContext context = request.getServletContext();   //筌롫�占쏙옙�쑓占쎌뵠占쎄숲占쎈퓠 占쎌뿳占쎈뮉 占쎈쨨占쎈쐭   
	      HttpSession session=request.getSession();
			Object userid = session.getAttribute("userid");
			String id=(String)userid;
			
	      String path = context.getRealPath("upload");   //占쎈뼄占쎌젫 野껋럥以�
	      String encType = "utf-8";
	      int sizeLimit = 1024*1024*20;  // 20mega
	      
	      MultipartRequest multi = new MultipartRequest(
	            request, 
	            path, 
	            sizeLimit, 
	            encType, 
	            new DefaultFileRenamePolicy()
	      );
		
		ReVO rvo = new ReVO();
		
		rvo.setPass(multi.getParameter("pass"));
		rvo.setName(multi.getParameter("name"));
		rvo.setUserid(id);
		rvo.setEmail(multi.getParameter("email"));
		rvo.setTitle(multi.getParameter("title"));
		rvo.setSourceLang(multi.getParameter("SourceLang"));
		rvo.setTargetLang(multi.getParameter("TargetLang"));
		rvo.setContent(multi.getParameter("content"));
		rvo.setRefile(multi.getFilesystemName("reflie"));
		String dline=multi.getParameter("deadline");	
		DateFormat sd=new SimpleDateFormat("yyyyMMdd");
			try {
				Date dd=sd.parse(dline);
				rvo.setDeadline(dd);
			} catch (ParseException e) {
			
				e.printStackTrace();
			}
	
		rvo.setCash(multi.getParameter("cash"));
		
		
		ReDAO rdao = ReDAO.getins();
		rdao.updateRe(rvo);
		
		MessageDao medao=MessageDao.getinstence();
		int count = medao.notreadcount(id);
		request.setAttribute("count", count);
		
		
		new JobListAction().execute(request, response);
	}
}













