package com.project.action;

import com.project.action.main.JoinForm;
import com.project.action.main.JoinSuccess;
import com.project.action.main.LoginForm;
import com.project.action.main.LoginSucess;
import com.project.action.main.Logout;
import com.project.action.main.MainPage;
import com.project.action.main.WeatherPage;

public class MainActionFactory {

	private MainActionFactory() {}
	private static MainActionFactory instance=new MainActionFactory();
	public static MainActionFactory getinstance() {
		return instance;
	}
	public Action getAction(String command) {
		Action action=null;
		
		if(command.equals("main")) {
			action=new MainPage();
		}else if(command.equals("weather")) {
			action= new WeatherPage();
		}else if(command.equals("joinform")) {
			action=new JoinForm();
		}else if(command.equals("joinsuccess")) {
			action=new JoinSuccess();
		}else if(command.equals("login")) {
			action =new LoginForm();
		}else if(command.equals("loginsuccess")) {
		action=new LoginSucess();
	}else if(command.equals("logout")) {
			action = new Logout();
		}
				
		return action;
	}
	
	
}
