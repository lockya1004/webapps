package com.project.action.transprofile;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dao.TransProfileDAO;
import com.project.dto.TransProfileVO;

public class TransProfileUpdateAction implements Action {

   @Override
   public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      request.setCharacterEncoding("utf-8");
      ServletContext context = request.getServletContext();
      
      String path = context.getRealPath("upload");
      String encType = "utf-8";
      int sizeLimit = 20*1024*1024;
      
      MultipartRequest multi = new MultipartRequest(
            request, 
            path, 
            sizeLimit, 
            encType, 
            new DefaultFileRenamePolicy()
      );
      
      String imgUrl = multi.getFilesystemName("PicUrl");
      String srcLanguage = multi.getParameter("SourceLangVal");  
      String area = multi.getParameter("Area");
      String portfolio = multi.getParameter("Portfolio");      
      String name = multi.getParameter("Name");
      String address = multi.getParameter("Address");
      String id = multi.getParameter("Id");
      String payRate = multi.getParameter("PayRate");
      String contact = multi.getParameter("Contact");
      String software = multi.getParameter("Software");
      String targLanguage = multi.getParameter("TargetLangVal");

      
      TransProfileVO vo = new TransProfileVO();
      //vo.setCode(code);
      vo.setImgUrl(imgUrl);
      vo.setSrcLanguage(srcLanguage);
      vo.setTargLanguage(targLanguage);
      vo.setArea(area);
      vo.setPortfolio(portfolio);
      vo.setAddress(address);
      vo.setName(name);
      vo.setId(id);
      vo.setPayRate(payRate);
      vo.setContact(contact);
      vo.setSoftware(software);
      
      

  	MessageDao medao=MessageDao.getinstence();
  	int count = medao.notreadcount(id);
  	request.setAttribute("count", count);
  	
      String url = "/Portfolio.do?command=portfolio_desc&id="+id;
      TransProfileDAO pDao = TransProfileDAO.getInstance();
      
      try {
         pDao.updateTransProfiles(vo);
      } catch (SQLException e) {
         e.printStackTrace();
      }
/*      
      if(getCode==null) {
         pDao.selectAllListById(id);
      } else {         
         pDao.selectAllListByCode(code);
      }*/

      RequestDispatcher dispatcher = request.getRequestDispatcher(url);
      dispatcher.forward(request, response);      
   }
}