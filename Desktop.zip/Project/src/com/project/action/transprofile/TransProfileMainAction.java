package com.project.action.transprofile;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dao.TransProfileDAO;
import com.project.dto.TransJobVO;

public class TransProfileMainAction implements Action{

	public TransProfileMainAction() {
	}

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String url = "/transMain.jsp";
		
		request.setCharacterEncoding("utf-8");
		TransProfileDAO pDao = TransProfileDAO.getInstance();
		
		List<TransJobVO> proJobList;
		try {
			proJobList = pDao.selectJobList();
			request.setAttribute("proJobList", proJobList);
			
			HttpSession session=request.getSession();
			String id=(String) session.getAttribute("userid");
			MessageDao medao=MessageDao.getinstence();
			int count = medao.notreadcount(id);
			request.setAttribute("count", count);
			RequestDispatcher dispatcher = request.getRequestDispatcher(url);
			dispatcher.forward(request, response);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
