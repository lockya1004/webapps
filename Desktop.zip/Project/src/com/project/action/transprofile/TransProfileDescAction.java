package com.project.action.transprofile;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dao.TransProfileDAO;
import com.project.dto.TransProfileVO;

public class TransProfileDescAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/profile/transProfileDescription.jsp";		
		String getCode = request.getParameter("code");
		request.setCharacterEncoding("utf-8");
	
		TransProfileDAO pDao = TransProfileDAO.getInstance();		
		TransProfileVO profileDesc;
		try {
			if(getCode==null) {
				String id = request.getParameter("id");
				profileDesc = pDao.selectAllListById(id);
			} else {
				int code = Integer.parseInt(getCode);
				profileDesc = pDao.selectAllListByCode(code);
			}
			
			request.setAttribute("profileDesc", profileDesc);
			RequestDispatcher dispatcher = request.getRequestDispatcher(url);	
			dispatcher.forward(request, response);
			
			HttpSession session=request.getSession();
			String id=(String) session.getAttribute("userid");
			MessageDao medao=MessageDao.getinstence();
			int count = medao.notreadcount(id);
			request.setAttribute("count", count);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
