package com.project.action.transprofile;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;

public class TransProfileWriteView implements Action{
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url=null;
		HttpSession session=request.getSession();
		String id = (String)session.getAttribute("userid");
		if(id==null) {
			url="/re/onlymember.jsp";
			}else {
			url = "/profile/transProfileWrite.jsp";
			}
		MessageDao medao=MessageDao.getinstence();
	  	int count = medao.notreadcount(id);
	  	request.setAttribute("count", count);
		request.getRequestDispatcher(url).forward(request, response);
		
	}

}
