package com.project.action.transprofile;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dao.TransProfileDAO;
import com.project.dto.TransProfileVO;

public class TransProfileReviewAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/profile/transProfileUpdate.jsp";
		request.setCharacterEncoding("utf-8");
		TransProfileDAO pDao = TransProfileDAO.getInstance();
		TransProfileVO profileReview;
		HttpSession session=request.getSession();
			String id=(String) session.getAttribute("userid");
		try {
			profileReview = pDao.selectAllListById(id);
			request.setAttribute("profileReview", profileReview);
			
			
			MessageDao medao=MessageDao.getinstence();
			int count = medao.notreadcount(id);
			request.setAttribute("count", count);
			RequestDispatcher dispatcher = request.getRequestDispatcher(url);	
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}