package com.project.action.clientprofile;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;

public class ClientProfileInsert implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		Object userid = session.getAttribute("userid");
		String id=(String) userid;
		String url=null;
		if(id==null) {
			url="/re/onlymember.jsp";
			}else {
				
				MessageDao medao=MessageDao.getinstence();
				int count = medao.notreadcount(id);
				request.setAttribute("count", count);	
				
			url = "/clientProfile/clientProfileWrite.jsp";
			}
		
	
		request.getRequestDispatcher(url).forward(request, response);
		

	}

}
