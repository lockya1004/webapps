package com.project.action.clientprofile;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.ClientProfileDAO;
import com.project.dao.MessageDao;
import com.project.dto.ClientProfileVO;


public class ClientProfileView implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="/clientProfile/clientView.jsp";
		request.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();
		Object userid=session.getAttribute("userid");
		String id=(String)userid;
		
		ClientProfileDAO cpdao=ClientProfileDAO.getinstance();
		int num=Integer.parseInt(request.getParameter("num"));
		ClientProfileVO cvo=cpdao.selected(num);
		request.setAttribute("cprofilelist", cvo);
		
		MessageDao medao=MessageDao.getinstence();
		int count = medao.notreadcount(id);
		request.setAttribute("count", count);	
			RequestDispatcher dispatcher=request.getRequestDispatcher(url);
			dispatcher.forward(request, response);
		

	}

}

