package com.project.action.clientprofile;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.ClientProfileDAO;
import com.project.dao.MessageDao;

public class ClientProfileDelete implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();

		String id=(String) session.getAttribute("id");
		ClientProfileDAO cdao=ClientProfileDAO.getinstance();
		cdao.delete(id);
		
		
		MessageDao medao=MessageDao.getinstence();
		int count = medao.notreadcount(id);
		request.setAttribute("count", count);
		new ClientProfileList().execute(request, response);


	}

}
