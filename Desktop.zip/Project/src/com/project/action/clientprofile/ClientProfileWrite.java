package com.project.action.clientprofile;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.project.action.Action;
import com.project.dao.ClientProfileDAO;
import com.project.dao.MessageDao;
import com.project.dto.ClientProfileVO;

public class ClientProfileWrite implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();
		String id=(String) session.getAttribute("userid");
		
		
		String path = request.getServletContext().getRealPath("upload");
		String encType = "UTF-8";
		int sizelimit = 1024 * 1024 * 20;
		MultipartRequest multi = new MultipartRequest(request, path, sizelimit, encType, new DefaultFileRenamePolicy());
		// DefaultFileRenamePolicy() 파일 저장 시, 덮어쓰지 못하게 이름을 변경시켜서 중복되지 않게 해줌. 꼭 써야함..
		ClientProfileVO cpvo = new ClientProfileVO();
		cpvo.setUserid(multi.getParameter("id"));
		cpvo.setName(multi.getParameter("name"));
		cpvo.setKinds(multi.getParameter("kinds"));
		cpvo.setAddress(multi.getParameter("add"));
		cpvo.setImage(multi.getFilesystemName("image"));

		ClientProfileDAO cpdao = ClientProfileDAO.getinstance();
		cpdao.CpWrite(cpvo);
		request.setAttribute("cpWrite", cpvo);
		
		MessageDao medao=MessageDao.getinstence();
		int count = medao.notreadcount(id);
		request.setAttribute("count", count);	
		new ClientProfileList().execute(request, response);
		
	}

}
