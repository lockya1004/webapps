package com.project.action.message;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dto.MessageVO;


public class MessageList_to implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="/message/messagelist_to.jsp";
		MessageDao dao=MessageDao.getinstence();
		HttpSession session=request.getSession();
		Object userid=session.getAttribute("userid");
		String id=(String) userid;
		
		String readnot=request.getParameter("readnot");
		if(readnot==null) {
			List<MessageVO> list=dao.sendtome(id);
			request.setAttribute("list_to", list);
			
			int count = dao.notreadcount(id);
			request.setAttribute("count", count);
			
		}else {
			
			List<MessageVO> list=dao.yetread(id,readnot);
			request.setAttribute("list_to", list);
			
			int count = dao.notreadcount(id);
			request.setAttribute("count", count);
			
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
		
	}

}
