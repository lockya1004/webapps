package com.project.action.message;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dto.MessageVO;

public class MessageView implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="message/messageView.jsp";
		int num=Integer.parseInt(request.getParameter("num"));
		MessageDao dao=MessageDao.getinstence();
		MessageVO vo=dao.readmessage(num);
		dao.updateread(num);
		request.setAttribute("list_to", vo);
		RequestDispatcher dispatcher=request.getRequestDispatcher(url);
		dispatcher.forward(request, response);

	}

}
