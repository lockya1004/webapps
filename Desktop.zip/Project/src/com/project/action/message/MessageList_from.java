package com.project.action.message;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dto.MessageVO;

public class MessageList_from implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();
		Object userid=session.getAttribute("userid");
		String id=(String)userid;
		MessageDao dao=MessageDao.getinstence();
		String readnot=request.getParameter("readnot");
		if(readnot==null) {
			List<MessageVO> sendmessage=dao.sendmessage(id);
			request.setAttribute("list_from", sendmessage);
			
			int count = dao.notreadcount(id);
			request.setAttribute("count", count);
			
		}else {
			List<MessageVO> sendmessage=dao.yetread(id,readnot);
			request.setAttribute("list_from", sendmessage);
			
			int count = dao.notreadcount(id);
			request.setAttribute("count", count);
			
		}

		RequestDispatcher dispatcher=request.getRequestDispatcher("message/messagelist_from.jsp");
		dispatcher.forward(request, response);
	}

}
