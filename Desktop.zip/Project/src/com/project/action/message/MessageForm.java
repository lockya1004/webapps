package com.project.action.message;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;

public class MessageForm implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String toid=request.getParameter("id");
		request.setAttribute("toid", toid);
		RequestDispatcher dispatcher=request.getRequestDispatcher("/message/messageForm.jsp");
		dispatcher.forward(request, response);
	}

}
