package com.project.action.message;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dto.MessageVO;

public class MessageWrite implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	request.setCharacterEncoding("UTF-8");
	MessageVO vo=new MessageVO();
	HttpSession session = request.getSession();
	Object userid=session.getAttribute("userid");
	String id=(String) userid;
	vo.setFromid(id);
	vo.setToid(request.getParameter("toid"));
	vo.setContent(request.getParameter("content"));
	System.out.println("toid : "+vo.getToid());
	System.out.println(vo.getContent());
	MessageDao dao=MessageDao.getinstence();
	dao.insert(vo);

	new MessageList_to().execute(request, response);
	
	}

}
