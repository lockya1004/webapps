package com.project.action.message;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.MessageDao;

public class MessageButtonMenu implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String btnid=request.getParameter("btnid");

		String num=request.getParameter("num");
		MessageDao dao=MessageDao.getinstence();
		
		if(btnid.equals("waste")) {
		String[] numlist = num.split(",");
		System.out.println(btnid);
		
		for(int i=0; i<numlist.length; i++) {
			System.out.println("tmp : "+numlist[i]);
			dao.updatewaste(Integer.parseInt(numlist[i]));
			}
		
		}else if(btnid.equals("keep")){
			String[] numlist = num.split(",");

			for(int i=0; i<numlist.length; i++) {
				System.out.println("tmp : "+numlist[i]);
				dao.updatekeep(Integer.parseInt(numlist[i]));
				}	
			
		}else if(btnid.equals("delete")) {
			String[] numlist = num.split(",");

			for(int i=0; i<numlist.length; i++) {
				System.out.println("tmp : "+numlist[i]);
				dao.messagedelete(Integer.parseInt(numlist[i]));
				}
			
		}else if(btnid.equals("alldel")){
			dao.alldelete();
		}
		
		new MessageList_to().execute(request, response);

	}

}
