package com.project.action.mypage;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dao.MypageDAO;
import com.project.dto.MypageVO;

public class MypageList implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		Object userid = session.getAttribute("userid");
	
		String id= (String) userid;
		String url="/mypage/mypage.jsp";
			MypageDAO mydao=MypageDAO.getinstance();
			
			MypageVO mvo=mydao.getist(id);
			List<MypageVO>list=mydao.boardList(id);
			request.setAttribute("myprofile", mvo);
			request.setAttribute("requestlist", list);
			

			MessageDao medao=MessageDao.getinstence();
			int count = medao.notreadcount(id);
			
			request.setAttribute("count", count);
			
			RequestDispatcher dispatcher=request.getRequestDispatcher(url);
			dispatcher.forward(request, response);
	}

}
