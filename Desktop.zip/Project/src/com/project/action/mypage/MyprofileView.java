package com.project.action.mypage;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;

import com.project.dao.MypageDAO;
import com.project.dto.MypageVO;

public class MyprofileView implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="/mypage/mypageView.jsp";
		MypageDAO mydao=MypageDAO.getinstance();
		HttpSession session=request.getSession();
		Object userid = session.getAttribute("userid");
		String id=(String) userid;
		MypageVO mvo=mydao.getist(id);
		request.setAttribute("myprofile",mvo);
		RequestDispatcher dispatcher=request.getRequestDispatcher(url);
		dispatcher.forward(request, response);

	}

}
