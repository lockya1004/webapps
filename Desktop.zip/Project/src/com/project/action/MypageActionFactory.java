package com.project.action;

import com.project.action.mypage.MypageList;
import com.project.action.mypage.MypagePass;
import com.project.action.mypage.MyprofileView;

public class MypageActionFactory {
	
	private MypageActionFactory(){}
	
	private static MypageActionFactory instance=new MypageActionFactory();
	
	public static MypageActionFactory getinstance() {
		return instance;
	}

	public Action getAction(String command) {
		Action action=null;
		
		if(command.equals("check_pass")) {
			action=new MypagePass();
		}else if(command.equals("mypageList")) {
			action=new MypageList();
		}else if(command.equals("mypageUpdate")) {
			action=new MyprofileView();
		}
		
		
		return action;
	}
	
}
