package com.project.action.main;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MemberDAO;
import com.project.dto.MemberVO;

public class LoginSucess implements Action{
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "member/login.jsp";
		String id = request.getParameter("userid");
		String pw = request.getParameter("pwd");
		
		MemberDAO dao = MemberDAO.getInstance();
		int r = dao.userCheck(id, pw);
		
		if(r==1) {
			MemberVO vo = dao.getMember(id);
			HttpSession se = request.getSession();
			se.setAttribute("userid", vo.getUserid());
			request.setAttribute("message", "로그인에 성공하였습니다");
			url = "/main.do?command=main";
		}else if(r==0) {
			request.setAttribute("message", "비밀번호가 맞지 않습니다.");	
		}else if(r==-1) {
			request.setAttribute("message", "존재하지 않는 회원입니다");
		}
		RequestDispatcher ds = request.getRequestDispatcher(url);
		ds.forward(request, response);
	}

}
