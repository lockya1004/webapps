package com.project.action.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.project.action.Action;
import com.project.dao.WeatherDao;
import com.project.dto.Weather;

public class WeatherPage implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		WeatherDao dao=WeatherDao.getinstance();
		dao.deleteWeather();
		WeatherPage pw=new WeatherPage();
		pw.weather();
      new MainPage().execute(request, response);
	}
	

	  public void weather(){
			try {
			String apiId="c08918b19d0762a7c8ef9e3c49c16174";
			String location="1835848,1838524,1835329,1843564,1841811,1835235,1833747,1846266";
			String urlstr = "http://api.openweathermap.org/data/2.5/group?id=" + location + "&units=metric&APPID=" + apiId;
			URL url=new URL(urlstr);
		  BufferedReader bf;
          String line;
          String result="";
          Weather wr=new Weather();
          WeatherDao dao=WeatherDao.getinstance();
          //날씨 정보를 받아온다.
          bf = new BufferedReader(new InputStreamReader(url.openStream()));

          //버퍼에 있는 정보를 문자열로 변환.
          while((line=bf.readLine())!=null){
              result=result.concat(line);
              //System.out.println(line);
          }
          System.out.println(result);
          //문자열을 JSON으로 파싱
          JSONParser jsonParser = new JSONParser();
          JSONObject jsonObj = (JSONObject) jsonParser.parse(result);
	
		  //날씨 출력
          JSONArray listArray = (JSONArray) jsonObj.get("list");
          for(int i=0; i<listArray.size();i++) {
          JSONObject obj = (JSONObject) listArray.get(i);
          System.out.println("obj : " + obj);
          //지역 출력
        
          System.out.println(obj.get("name").toString());
          wr.setLocation(obj.get("name").toString());
          JSONArray weatherarr=(JSONArray) obj.get("weather");
          JSONObject weatherobj = (JSONObject) weatherarr.get(0);
          System.out.println("날씨 : "+weatherobj.get("icon"));
          wr.setIcon(weatherobj.get("icon").toString());
         //온도 출력(절대온도라서 변환 필요)
          JSONObject mainArray = (JSONObject) obj.get("main");
         double ktemp =Double.parseDouble(mainArray.get("temp").toString());
          wr.setTemp(Math.round(ktemp));
          System.out.printf("온도 :"+wr.getTemp());
          dao.insertWeather(wr);
          }
          bf.close();
			}catch(Exception e){
				e.printStackTrace();
      }

}
	

}
	
