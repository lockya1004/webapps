package com.project.action.support;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;

public class SupportWriteAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="support/supportWrite.jsp";
		
		HttpSession session=request.getSession();
		String id=(String) session.getAttribute("userid");
		MessageDao medao=MessageDao.getinstence();
		int count = medao.notreadcount(id);
		request.setAttribute("count", count);
		response.sendRedirect(url);
	}

}
