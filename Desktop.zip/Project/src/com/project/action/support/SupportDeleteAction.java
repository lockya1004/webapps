package com.project.action.support;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MessageDao;
import com.project.dao.SupportDAO;

public class SupportDeleteAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	int num=Integer.parseInt(request.getParameter("num"));
	SupportDAO sdao=SupportDAO.getinstance();
	HttpSession session=request.getSession();
	String id=(String)session.getAttribute("userid");
	
	sdao.deleteSupport(num);
	MessageDao medao=MessageDao.getinstence();
	int count = medao.notreadcount(id);
	request.setAttribute("count", count);
	
	new SupportSearchAction().execute(request, response);
		
	}

}
