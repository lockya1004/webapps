package com.project.action;

import com.project.action.message.MessageButtonMenu;
import com.project.action.message.MessageForm;
import com.project.action.message.MessageList_from;
import com.project.action.message.MessageList_keep;
import com.project.action.message.MessageList_to;
import com.project.action.message.MessageList_waste;
import com.project.action.message.MessageView;
import com.project.action.message.MessageWrite;

public class MessageFactory {

	private MessageFactory() {}
	private static MessageFactory instance=new MessageFactory();
	public static MessageFactory getinstance() {
		return instance;
	}
	public Action getAction(String command) {
		Action action=null;
		
		if(command.equals("form")) {
			action=new MessageForm();
		}else if(command.equals("write")) {
			action= new MessageWrite();
		}else if(command.equals("view")) {
			action=new MessageView();
		}else if(command.equals("btn")) {
			action=new MessageButtonMenu();
		}else if(command.equals("list_from")) {
			action =new MessageList_from();
		}else if(command.equals("list_to")) {
			action = new MessageList_to();
		}else if(command.equals("list_waste")) {
			action =new MessageList_waste();
		}else if(command.equals("list_keep")) {
			action = new MessageList_keep();
		}
		
		// ACTION LIST = FROM, TO, WASTE, KEEP, NOT READ
		// ���� ���� �� = FORM, ���� DB ���� = WRITE, DB �ҷ��ͼ� ���� = VIEW, ���������� = WASETE, ������ ���� = DELETE, �����ϱ� = KEEP    
		
		return action;
	}
	
}
