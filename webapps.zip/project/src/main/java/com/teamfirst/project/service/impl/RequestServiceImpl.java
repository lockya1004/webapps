
package com.teamfirst.project.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.teamfirst.project.dao.RequestDAO;
import com.teamfirst.project.model.RequestModel;
import com.teamfirst.project.service.RequestService;

@Service("requestService")
public class RequestServiceImpl implements RequestService{

	@Inject
	private RequestDAO reqDAO;

	@Override
	public List<RequestModel> getAllRequest() {
		return reqDAO.getAllRequest();
	}

	@Override
	public int regRequest(RequestModel model) {
		return reqDAO.regRequest(model);
	}

	@Override
	public int updateReadCount(String num) {
		return reqDAO.updateReadCount(num);
	}

	@Override
	public RequestModel getRequestDetailsByNum(String num) {
		return reqDAO.getRequestDetailsByNum(num);
	}

	@Override
	public int updateRequest(RequestModel model) {
		return reqDAO.updateRequest(model);
	}

	@Override
	public RequestModel checkPassWord(String pass, String num) {
		return reqDAO.checkPassWord(pass, num);
	}

	@Override
	public int delRequest(String num) {
		return reqDAO.delRequest(num);
	}

	@Override
	public List<RequestModel> getRequestList() {
		return reqDAO.getRequestList();
	}

}
