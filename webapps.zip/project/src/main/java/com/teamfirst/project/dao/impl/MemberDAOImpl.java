package com.teamfirst.project.dao.impl;

import java.util.HashMap;
import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamfirst.project.dao.MemberDAO;
import com.teamfirst.project.model.LoginModel;
import com.teamfirst.project.model.MemberModel;

@Repository("memberDAO")
public class MemberDAOImpl implements MemberDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public MemberModel login(LoginModel loginModel) {
		
		return sqlSession.selectOne("login", loginModel);
	}

	@Override
	public MemberModel getMemberList(String userid) {		
		return sqlSession.selectOne("selectMemberView", userid);
	}

	@Override
	public int conrfirmMember(String userid) {
		int result;
		String member = sqlSession.selectOne("conrfirmMember", userid);
		if(member!=null){
			result = 1;
		} else{
			result = -1;
		}
		return result;
	}

	@Override
	public int regMember(MemberModel model) {		
		return sqlSession.insert("insertMembers", model);
	}

	@Override
	public int updateMember(MemberModel model) {		
		return sqlSession.update("updateMember", model);
	}

	@Override
	public MemberModel checkUserWithSessionKey(String value) {
		return sqlSession.selectOne("checkUserWithSessionKey", value);
	}
}
