package com.teamfirst.project.controller;

import java.io.File;
import java.sql.SQLException;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.teamfirst.project.model.MainModel;
import com.teamfirst.project.model.MemberModel;
import com.teamfirst.project.model.RequestModel;
import com.teamfirst.project.service.MemberService;
import com.teamfirst.project.service.RequestService;

@Controller
public class RequestController {

	@Inject
	private RequestService requestService;


	@RequestMapping("/request/go.view")
	public String reqView(Model model, @RequestParam("num") String num) throws SQLException {
		requestService.updateReadCount(num);		
		RequestModel reqModel = requestService.getRequestDetailsByNum(num);
		
		model.addAttribute("req", reqModel);
		model.addAttribute("req", getSelectedLang(reqModel));
		
		return "request/reqView";
	}
		
	@RequestMapping("/request/go.list")
	public String reqList(Model model) throws SQLException {
		
		List<RequestModel> listReqModel = requestService.getAllRequest();
	
		model.addAttribute("reqlist", listReqModel);
		model.addAttribute("reqlist", getLang(listReqModel));
		
		return "request/reqList";
	}
	
	@RequestMapping("/request/go.register")
	public String reqWrite(HttpSession session, Model model) throws SQLException {
		
		return "request/reqWrite";
	}
	
	
	@RequestMapping(value="/request/go.insert", method=RequestMethod.POST)
	public String reqInsert(RequestModel model) throws SQLException {
		requestService.regRequest(model);
				
		return "redirect:/request/go.list";
	}
	
	public List<RequestModel> getLang(List<RequestModel> requestModel) {
		String srcLanguage = "";
		String targlanguage = "";

		try {
			
			//xml file location
			String fileurl = this.getClass().getResource("").getPath();
			String path = fileurl.substring(1, fileurl.indexOf("project")) + "project/resources/xml/languages.xml";
			Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(path));
			doc.getDocumentElement().normalize();
			XPath xPath = XPathFactory.newInstance().newXPath();

			for (int j = 0; j < requestModel.size(); j++) {
				String expSourceLang = "/languages/language[value=" + requestModel.get(j).getSourceLang() + "]";
				String expTargetLang = "/languages/language[value=" + requestModel.get(j).getTargetLang() + "]";

				Node nodeSourceLang = (Node) xPath.compile(expSourceLang).evaluate(doc, XPathConstants.NODE);
				NodeList nodeSourceLangList = (NodeList) xPath.compile(expSourceLang).evaluate(doc, XPathConstants.NODESET);

				Node nodeTargetLang = (Node) xPath.compile(expTargetLang).evaluate(doc, XPathConstants.NODE);
				NodeList nodeTargetLangList = (NodeList) xPath.compile(expTargetLang).evaluate(doc, XPathConstants.NODESET);

				//if (null != nodeSourceLang||null != nodeTargetLang) 
				{
					nodeSourceLangList = nodeSourceLang.getChildNodes();
					nodeTargetLangList = nodeTargetLang.getChildNodes();
					
					for (int i = 0; i < nodeSourceLangList.getLength(); i++) {  //null != nodeSourceLangList && 
						Node nodeSource = nodeSourceLangList.item(i);
						Node nodeTarget = nodeTargetLangList.item(i);
						if (nodeSource.getNodeType() == Node.ELEMENT_NODE){
							srcLanguage = nodeSource.getFirstChild().getNodeValue(); //
						}
						if (nodeTarget.getNodeType() == Node.ELEMENT_NODE){
							targlanguage = nodeTarget.getFirstChild().getNodeValue(); //
						}
					}
				}
				requestModel.get(j).setSource(srcLanguage);
				requestModel.get(j).setTarget(targlanguage);				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return requestModel;
	}
	
	public RequestModel getSelectedLang(RequestModel requestModel) {
		String srcLanguage = "";
		String targlanguage = "";

		try {
			
			//xml file location
			String fileurl = this.getClass().getResource("").getPath();
			String path = fileurl.substring(1, fileurl.indexOf("project")) + "project/resources/xml/languages.xml";
			Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(path));
			doc.getDocumentElement().normalize();
			XPath xPath = XPathFactory.newInstance().newXPath();
			
			{
				String expSourceLang = "/languages/language[value=" + requestModel.getSourceLang() + "]";
				String expTargetLang = "/languages/language[value=" + requestModel.getTargetLang() + "]";

				Node nodeSourceLang = (Node) xPath.compile(expSourceLang).evaluate(doc, XPathConstants.NODE);
				NodeList nodeSourceLangList = (NodeList) xPath.compile(expSourceLang).evaluate(doc, XPathConstants.NODESET);

				Node nodeTargetLang = (Node) xPath.compile(expTargetLang).evaluate(doc, XPathConstants.NODE);
				NodeList nodeTargetLangList = (NodeList) xPath.compile(expTargetLang).evaluate(doc, XPathConstants.NODESET);

				//if (null != nodeSourceLang||null != nodeTargetLang) 
				{
					nodeSourceLangList = nodeSourceLang.getChildNodes();
					nodeTargetLangList = nodeTargetLang.getChildNodes();
					
					for (int i = 0; i < nodeSourceLangList.getLength(); i++) {  //null != nodeSourceLangList && 
						Node nodeSource = nodeSourceLangList.item(i);
						Node nodeTarget = nodeTargetLangList.item(i);
						if (nodeSource.getNodeType() == Node.ELEMENT_NODE){
							srcLanguage = nodeSource.getFirstChild().getNodeValue(); //
						}
						if (nodeTarget.getNodeType() == Node.ELEMENT_NODE){
							targlanguage = nodeTarget.getFirstChild().getNodeValue(); //
						}
					}
				}
				requestModel.setSource(srcLanguage);
				requestModel.setTarget(targlanguage);				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return requestModel;
	}
}
