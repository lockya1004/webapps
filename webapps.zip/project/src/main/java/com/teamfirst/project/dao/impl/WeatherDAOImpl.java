package com.teamfirst.project.dao.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Repository;

import com.teamfirst.project.dao.WeatherDAO;
import com.teamfirst.project.model.WeatherModel;

@Repository("weatherDAO")
public class WeatherDAOImpl implements WeatherDAO {

	@Inject
	private SqlSession sqlSession;
	
//	private static final String NAMESPACE = "com.teamfirst.project.dao.WeatherDAO";
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public int regWeather(WeatherModel model) {
		return sqlSession.insert("insertWeather", model);
	}

	@Override
	public int delWeather() {
		return sqlSession.delete("delWeather");
	}

	@Override
	public List<WeatherModel> getWeather() {
			List<WeatherModel> listWeather = sqlSession.selectList("selectWeather");
			if(listWeather == null){
				
			}
		
		return listWeather;
	}    		
	
	  public void weather(){
			try {
			String apiId="c08918b19d0762a7c8ef9e3c49c16174";
			String location="1835848,1838524,1835329,1843564,1841811,1835235,1833747,1846266";
			String urlstr = "http://api.openweathermap.org/data/2.5/group?id=" + location + "&units=metric&APPID=" + apiId;
			URL url=new URL(urlstr);
			BufferedReader bf;
        String line;
        String result="";
        WeatherModel wr=new WeatherModel();

        //날씨 정보를 받아온다.
        bf = new BufferedReader(new InputStreamReader(url.openStream()));

        //버퍼에 있는 정보를 문자열로 변환.
        while((line=bf.readLine())!=null){
            result=result.concat(line);
            //System.out.println(line);
        }
        System.out.println(result);
        //문자열을 JSON으로 파싱
        JSONParser jsonParser = new JSONParser();
        JSONObject jsonObj = (JSONObject) jsonParser.parse(result);
	
		  //날씨 출력
        JSONArray listArray = (JSONArray) jsonObj.get("list");
        for(int i=0; i<listArray.size();i++) {
        JSONObject obj = (JSONObject) listArray.get(i);
        System.out.println("obj : " + obj);
        //지역 출력
      
        System.out.println(obj.get("name").toString());
        wr.setLocation(obj.get("name").toString());
        JSONArray weatherarr=(JSONArray) obj.get("weather");
        JSONObject weatherobj = (JSONObject) weatherarr.get(0);
        System.out.println("날씨 : "+weatherobj.get("icon"));
        wr.setIcon(weatherobj.get("icon").toString());
       //온도 출력(절대온도라서 변환 필요)
        JSONObject mainArray = (JSONObject) obj.get("main");
       double ktemp =Double.parseDouble(mainArray.get("temp").toString());
        wr.setTemp(Math.round(ktemp));
        System.out.printf("온도 :"+wr.getTemp());
        sqlSession.insert(wr);
        }
        bf.close();
			}catch(Exception e){
				e.printStackTrace();
    }

}
	  
	
	
}
