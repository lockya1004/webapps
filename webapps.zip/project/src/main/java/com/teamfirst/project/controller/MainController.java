package com.teamfirst.project.controller;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.teamfirst.project.model.MainModel;
import com.teamfirst.project.service.MainService;
import com.teamfirst.project.service.WeatherService;

@Controller
public class MainController {

	@Inject
	private MainService mainService;
	@Inject
	private WeatherService weatherService;

	@RequestMapping("/")
	public String main(Model model) throws SQLException {
		List<MainModel> listMainModel = mainService.getNewList();

//		List<String> srcLangList = getLang(listMainModel); 
//		model.addAttribute("srcLang", mainService.getLangList());
				
		model.addAttribute("main", listMainModel);
		model.addAttribute("main", getLang(listMainModel));		
		
		model.addAttribute("weatherlist", weatherService.getWeather());
		
		return "main";
	}

	@RequestMapping(method = RequestMethod.GET, value = "header")
	public String header(Model model) {
		return "include/header";
	}

	@RequestMapping(method = RequestMethod.GET, value = "footer")
	public String footer(Model model) {
		return "include/footer";
	}

	public List<MainModel> getLang(List<MainModel> mainModel) {
		String srcLanguage = "";
		String targlanguage = "";

		try {
			
			//xml file location
			String fileurl = this.getClass().getResource("").getPath();
			String path = fileurl.substring(1, fileurl.indexOf("project")) + "project/resources/xml/languages.xml";
			Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(path));
			doc.getDocumentElement().normalize();
			XPath xPath = XPathFactory.newInstance().newXPath();

			for (int j = 0; j < mainModel.size(); j++) {
				String expSourceLang = "/languages/language[value=" + mainModel.get(j).getSourceLang() + "]";
				String expTargetLang = "/languages/language[value=" + mainModel.get(j).getTargetLang() + "]";

				Node nodeSourceLang = (Node) xPath.compile(expSourceLang).evaluate(doc, XPathConstants.NODE);
				NodeList nodeSourceLangList = (NodeList) xPath.compile(expSourceLang).evaluate(doc, XPathConstants.NODESET);

				Node nodeTargetLang = (Node) xPath.compile(expTargetLang).evaluate(doc, XPathConstants.NODE);
				NodeList nodeTargetLangList = (NodeList) xPath.compile(expTargetLang).evaluate(doc, XPathConstants.NODESET);

				//if (null != nodeSourceLang||null != nodeTargetLang) 
				{
					nodeSourceLangList = nodeSourceLang.getChildNodes();
					nodeTargetLangList = nodeTargetLang.getChildNodes();
					
					for (int i = 0; i < nodeSourceLangList.getLength(); i++) {  //null != nodeSourceLangList && 
						Node nodeSource = nodeSourceLangList.item(i);
						Node nodeTarget = nodeTargetLangList.item(i);
						if (nodeSource.getNodeType() == Node.ELEMENT_NODE){
							srcLanguage = nodeSource.getFirstChild().getNodeValue(); //
						}
						if (nodeTarget.getNodeType() == Node.ELEMENT_NODE){
							targlanguage = nodeTarget.getFirstChild().getNodeValue(); //
						}
					}
				}
				mainModel.get(j).setSource(srcLanguage);
				mainModel.get(j).setTarget(targlanguage);				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return mainModel;
	}
}
