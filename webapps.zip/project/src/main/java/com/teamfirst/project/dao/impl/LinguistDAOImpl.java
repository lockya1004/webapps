package com.teamfirst.project.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamfirst.project.dao.LinguistDAO;
import com.teamfirst.project.model.JobModel;
import com.teamfirst.project.model.LinguistModel;

@Repository("linguistDAO")
public class LinguistDAOImpl implements LinguistDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public int regLinguist(LinguistModel model) {
		return sqlSession.insert("insertLinguist", model);
	}

	@Override
	public List<LinguistModel> getLinguistList() {
		return sqlSession.selectList("selectLinguistList");
	}

	@Override
	public LinguistModel getLinguistListByNum(int num) {
		return sqlSession.selectOne("selectLinguistByNum", num);
	}

	@Override
	public LinguistModel getLinguistListById(String id) {
		return sqlSession.selectOne("selectLinguistById", id);
	}

	@Override
	public LinguistModel getLinguistListByCode(int code) {
		return sqlSession.selectOne("selectLinguistByCode", code);
	}

	@Override
	public int updateLinguist(LinguistModel model) {
		return sqlSession.update("updateLinguist", model);
	}

	@Override
	public List<JobModel> getJobList() {
		return sqlSession.selectList("selectJobList");
	}

	@Override
	public List<LinguistModel> searchLinguist(String keyword) {
		return sqlSession.selectList("searchLinguistsByKeyword", keyword);
	}     	
}
