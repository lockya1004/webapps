package com.teamfirst.project.dao;

import com.teamfirst.project.model.LoginModel;
import com.teamfirst.project.model.MemberModel;

public interface MemberDAO {
	MemberModel getMemberList(String userid);
	int conrfirmMember(String userid);
	int regMember(MemberModel model);
	int updateMember(MemberModel model);
	MemberModel login(LoginModel loginModel);
	MemberModel checkUserWithSessionKey(String value);	
//	MemberModel checkLoginBefore(String value);
}
