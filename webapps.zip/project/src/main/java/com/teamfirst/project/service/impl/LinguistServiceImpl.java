package com.teamfirst.project.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.teamfirst.project.dao.LinguistDAO;
import com.teamfirst.project.model.JobModel;
import com.teamfirst.project.model.LinguistModel;
import com.teamfirst.project.service.LinguistService;

@Service("linguistService")
public class LinguistServiceImpl implements LinguistService{

	@Inject
	private LinguistDAO linguistDAO;

	@Override
	public int regLinguist(LinguistModel model) {
		return linguistDAO.regLinguist(model);
	}

	@Override
	public List<LinguistModel> getLinguistList() {
		return linguistDAO.getLinguistList();
	}

	@Override
	public LinguistModel getLinguistListByNum(int num) {
		return linguistDAO.getLinguistListByNum(num);
	}

	@Override
	public LinguistModel getLinguistListById(String id) {
		return linguistDAO.getLinguistListById(id);
	}

	@Override
	public LinguistModel getLinguistListByCode(int code) {
		return linguistDAO.getLinguistListByCode(code);
	}

	@Override
	public int updateLinguist(LinguistModel model) {
		return linguistDAO.updateLinguist(model);
	}

	@Override
	public List<JobModel> getJobList() {
		return linguistDAO.getJobList();
	}

	@Override
	public List<LinguistModel> searchLinguist(String keyword) {
		return linguistDAO.searchLinguist(keyword);
	}
}
