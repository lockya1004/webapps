package com.teamfirst.project.service.impl;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.teamfirst.project.service.JobService;

@Service("linguistJobService")
public class JobServiceImpl implements JobService{

//	@Inject
//	private Lin transJobDAO;
	

}
