package com.teamfirst.project.controller;

import java.sql.SQLException;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.teamfirst.project.model.MemberModel;
import com.teamfirst.project.service.MemberService;

@Controller
@RequestMapping("/join")
public class MemberController {

	@Inject
	private MemberService memberService;
	
	@RequestMapping("")
	public String memberJoinForm( ){
		return "member/memberJoin";    
	}
	
	@RequestMapping("/go.join")
	public String memberJoin(@RequestParam MemberModel model) throws SQLException{
//		model.addAttribute("main", memberService.getNewList());
//		response.sendRedirect("member/memberJoin");
		memberService.regMember(model);
		return "/";    //return "redirect:loginForm.do"

	}
}
