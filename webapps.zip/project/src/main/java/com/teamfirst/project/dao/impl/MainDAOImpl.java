package com.teamfirst.project.dao.impl;

import java.util.List;
import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.teamfirst.project.dao.MainDAO;
import com.teamfirst.project.model.MainModel;

@Repository("mainDAO")
public class MainDAOImpl implements MainDAO {

	@Inject
	private SqlSession sqlSession;
	
//	private static final String NAMESPACE = "com.teamfirst.project.dao.MainDAO";
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public List<MainModel> getNewList() {
/*		if(sqlSession == null){
//			System.out.println("���� �� ����");
		}else{
//			System.out.println("���� �� ����");
		}*/
		return sqlSession.selectList("selectNewList");
//		return sqlSession.selectList("selectNewList");
	}   	
}
