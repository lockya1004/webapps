package com.teamfirst.project.service.impl;

import javax.inject.Inject;
import org.springframework.stereotype.Service;

import com.teamfirst.project.dao.ClientDAO;
import com.teamfirst.project.model.ClientModel;
import com.teamfirst.project.service.ClientService;

@Service("clientService")
public class ClientServiceImpl implements ClientService{

	@Inject
	private ClientDAO clientDAO;
	
	@Override
	public int regClient(ClientModel model) {		
		return clientDAO.regClient(model);
	}

}
