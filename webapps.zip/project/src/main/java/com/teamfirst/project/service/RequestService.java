package com.teamfirst.project.service;

import java.sql.SQLException;
import java.util.List;
import com.teamfirst.project.model.RequestModel;

public interface RequestService {
	
	List<RequestModel> getAllRequest() throws SQLException;
	int regRequest(RequestModel model) throws SQLException;
	int updateReadCount(String num) throws SQLException;
	RequestModel getRequestDetailsByNum(String num) throws SQLException;
	int updateRequest(RequestModel model) throws SQLException;
	RequestModel checkPassWord(String pass, String num) throws SQLException;
	int delRequest(String num) throws SQLException;
	List<RequestModel> getRequestList() throws SQLException;
	
	
/*    int regContent(Map<String, Object> paramMap);   
    int getContentCnt(Map<String, Object> paramMap);     
    List<Board> getContentList(Map<String, Object> paramMap);     
    Board getContentView(Map<String, Object> paramMap);     
    int regRequest(Map<String, Object> paramMap);     
    List<BoardRequest> getRequestList(Map<String, Object> paramMap);     
    int delRequest(Map<String, Object> paramMap);     
    int getBoardCheck(Map<String, Object> paramMap);     
    int delBoard(Map<String, Object> paramMap);*/
}
