package com.teamfirst.project.service.impl;

import java.sql.SQLException;
import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.teamfirst.project.dao.MemberDAO;
import com.teamfirst.project.model.LoginModel;
import com.teamfirst.project.model.MemberModel;
import com.teamfirst.project.service.MemberService;

@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Inject
	private MemberDAO memberDAO;

	@Override
	public MemberModel login(LoginModel loginModel) throws SQLException {

		return memberDAO.login(loginModel);
	}
	
	@Override
	public MemberModel getMemberList(String userid) {
		return memberDAO.getMemberList(userid);
	}

	@Override
	public int conrfirmMember(String userid) {
		return memberDAO.conrfirmMember(userid);
	}

	@Override
	public int regMember(MemberModel model) {
		return memberDAO.regMember(model);
	}

	@Override
	public int updateMember(MemberModel model) {
		return memberDAO.updateMember(model);
	}

	@Override
	public MemberModel checkLoginBefore(String value) throws SQLException {
		
		return memberDAO.checkUserWithSessionKey(value);
	}

	@Override
	public MemberModel checkMember(String userid) throws SQLException {
		return memberDAO.checkMember(userid);
	}
	
	

}
