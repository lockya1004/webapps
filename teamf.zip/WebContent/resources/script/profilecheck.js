/**
 * 
 */

function  CPcheck() {
	
	if(document.frm.name.value.length==0){
		alert("이름 또는 회사명을 입력해주세요");
		frm.id.focus();
		return false;
	}
	
	
	if (document.frm.kinds.value == "") {
		alert("개인 또는 회사를 선택 하세요");
		return false;
	}
	if(document.frm.add.value.length==0){
		alert("주소를 입력해주세요");
		frm.email.focus();
		return false;
	}
	
	return true;
}

function check() {

	if(document.frm.keyword.value.length==0){
		alert("검색어를 입력해주세요");
		frm.email.focus();
		return false;
	}
return true;
}