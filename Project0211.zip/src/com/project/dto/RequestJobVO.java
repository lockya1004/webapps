package com.project.dto;

import java.sql.Timestamp;

public class RequestJobVO {
	private int num;
	private String title;
	private String language;
	private String content;
	private String requestfile;
	private Timestamp requestdate;
	private Timestamp deadline;
	private String now;
	private String id;
	
	public String getNow() {
		return now;
	}
	public void setNow(String now) {
		this.now = now;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRequestfile() {
		return requestfile;
	}
	public void setRequestfile(String requestfile) {
		this.requestfile = requestfile;
	}
	public Timestamp getRequestdate() {
		return requestdate;
	}
	public void setRequestdate(Timestamp requestdate) {
		this.requestdate = requestdate;
	}
	public Timestamp getDeadline() {
		return deadline;
	}
	public void setDeadline(Timestamp deadline) {
		this.deadline = deadline;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
}
