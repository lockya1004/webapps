package com.project.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.action.main.MainActionFactory;
import com.project.action.requestjob.JobActionFactory;

/**
 * Servlet implementation class JobServlet
 */
@WebServlet("/job.do")
public class JobServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JobServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 		HttpSession session=request.getSession();
 		//String id= (String) session.getAttribute("id");
 		String command=request.getParameter("command");
 		JobActionFactory jaf=JobActionFactory.getinstance();
 		Action action=jaf.getAction(command); 
 		if(action != null) {
 			action.execute(request, response);	
 		}else {
 			System.out.println("오류");
 		}
 				
 	}

 	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 		request.setCharacterEncoding("UTF-8");
 		doGet(request, response);
 	}
}

