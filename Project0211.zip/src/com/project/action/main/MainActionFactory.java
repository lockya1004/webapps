package com.project.action.main;

import com.project.action.Action;

public class MainActionFactory {

	private MainActionFactory() {}
	private static MainActionFactory instance=new MainActionFactory();
	public static MainActionFactory getinstance() {
		return instance;
	}
	public Action getAction(String command) {
		Action action=null;
		
		if(command.equals("main")) {
			action=new MainPage();
		}
				
		return action;
	}
	
}
