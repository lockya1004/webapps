package com.project.action.mypage;

import com.project.action.Action;
import com.project.action.clientprofile.ClientProfileDelete;
import com.project.action.clientprofile.ClientProfileUpdate;
import com.project.action.clientprofile.ClientProfileView;

public class MypageActionFactory {
	
	private MypageActionFactory(){}
	
	private static MypageActionFactory instance=new MypageActionFactory();
	
	public static MypageActionFactory getinstance() {
		return instance;
	}

	public Action getAction(String command) {
		Action action=null;
		
		if(command.equals("mypageUpdate")) {
			action=new MyprofileView();
		}else if(command.equals("mypageDelete")) {
			action=new MyprofileView();
		}else if(command.equals("mypageList")) {
			action=new MypageList();
		}
		
		
		return action;
	}
	
}
