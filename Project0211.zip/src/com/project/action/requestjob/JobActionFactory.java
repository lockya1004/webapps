package com.project.action.requestjob;

import com.project.action.Action;

public class JobActionFactory{
	private JobActionFactory(){}
	private static JobActionFactory instance=new JobActionFactory();
	public static JobActionFactory getinstance() {
		return instance;
	}

	public Action getAction(String command) {
		Action action=null;
		if(command.equals("joblist")) {
			action =new JobListAction();
		}
		return action;
	}
	
}
