package com.project.action.clientprofile;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.ClientProfileDAO;
import com.project.dto.ClientProfileVO;


public class ClientProfileView implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="/ClientProfile/clientProfileView.jsp";
		ClientProfileDAO cpdao=ClientProfileDAO.getinstance();
		String id=request.getParameter("id");
		ClientProfileVO cvo=cpdao.selected(id);
		request.setAttribute("cprofilelist", cvo);
		RequestDispatcher dispatcher=request.getRequestDispatcher(url);
		dispatcher.forward(request, response);

	}

}
