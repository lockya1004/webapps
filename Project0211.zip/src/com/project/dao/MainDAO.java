package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.project.dto.MainVO;
import com.project.util.DBManager;

public class MainDAO {

	// 싱글톤
		private MainDAO(){
		}

		private static MainDAO instance = new MainDAO();

	public static MainDAO getinstance() {
		return instance;
	}

	public List<MainVO> newList(){ 
	String sql="select * from (select * from REQUESTJOB order by num desc) where ROWNUM <=5 and now='의뢰'";
	List<MainVO> list=new ArrayList<MainVO>();
	Connection conn=null;
	PreparedStatement pstmt=null;
	ResultSet rs=null;
	
	try {
		conn=DBManager.getConnection();
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			MainVO vo=new MainVO();
			vo.setNum(rs.getInt("num"));
			vo.setTitle(rs.getString("title"));
			vo.setLanguage(rs.getString("language"));
			vo.setRequestdate(rs.getTimestamp("requestdate"));
			vo.setId(rs.getString("id"));
			list.add(vo);
		}
		
		
	} catch (Exception e) {
		e.printStackTrace();
	
	}finally {
		try {
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}
	
	
	
	return list;
	}
}
