package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.project.dto.MainVO;
import com.project.dto.RequestJobVO;
import com.project.util.DBManager;

public class JobDAO {
	// 싱글톤
	private JobDAO(){
	}

	private static JobDAO instance = new JobDAO();

public static JobDAO getinstance() {
	return instance;
}

public List<RequestJobVO> newList(){ 
	String sql="select * from REQUESTJOB order by num desc";
	List<RequestJobVO> list=new ArrayList<RequestJobVO>();
	Connection conn=null;
	PreparedStatement pstmt=null;
	ResultSet rs=null;
	
	try {
		conn=DBManager.getConnection();
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			RequestJobVO vo=new RequestJobVO();
			vo.setNum(rs.getInt("num"));
			vo.setTitle(rs.getString("title"));
			vo.setLanguage(rs.getString("language"));
			vo.setRequestdate(rs.getTimestamp("requestdate"));
			vo.setId(rs.getString("id"));
			vo.setNow(rs.getString("now"));
			list.add(vo);
		}
		
		
	} catch (Exception e) {
		e.printStackTrace();
	
	}finally {
		try {
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}
	
	
	
	return list;
	}


}
