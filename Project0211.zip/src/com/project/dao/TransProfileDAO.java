package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.project.dto.TransJobVO;
import com.project.dto.TransProfileVO;
import com.project.util.TransProfileDBManager;

public class TransProfileDAO {
	
	private TransProfileDAO() {}
	
	private static TransProfileDAO instance = new TransProfileDAO();
	
	public static TransProfileDAO getInstance() {		
		return instance;
	}
	
	public void writeTransProfiles(TransProfileVO vo) throws SQLException {
		String sql = "insert into "
				+ "transProfile(trans_num, trans_picurl, trans_src_language, trans_area, trans_portfolio, "
				+ "trans_name, trans_address, trans_id, trans_payrate, trans_contact, trans_software, trans_targ_language) "
				+ "values(trans_seq.nextval, ?,?,?,?,?,?,?,?,?,?,?)";
		Connection conn= null;
		PreparedStatement pstmt = null;		
		try {
			conn = TransProfileDBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getImgUrl());
			pstmt.setString(2, vo.getSrcLanguage());
			pstmt.setString(3, vo.getArea());
			pstmt.setString(4, vo.getPortfolio());
			pstmt.setString(5, vo.getName());
			pstmt.setString(6, vo.getAddress());
			pstmt.setString(7, vo.getId());
			pstmt.setString(8, vo.getPayRate());
			pstmt.setString(9, vo.getContact());
			pstmt.setString(10, vo.getSoftware());
			pstmt.setString(11, vo.getTargLanguage());
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			conn.close();
		}		
	}

	public List<TransProfileVO> selectAllList() throws SQLException {
		String sql = "select * from transProfile order by trans_num desc";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<TransProfileVO> list = new ArrayList<TransProfileVO>();
		
		try {
			conn = TransProfileDBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				TransProfileVO vo = new TransProfileVO();
				vo.setCode(rs.getInt("TRANS_NUM"));
				vo.setImgUrl(rs.getString("TRANS_PICURL"));
				vo.setAddress(rs.getString("TRANS_ADDRESS"));
				vo.setSrcLanguage(rs.getString("TRANS_SRC_LANGUAGE"));
				vo.setArea(rs.getString("TRANS_AREA"));
				vo.setPortfolio(rs.getString("TRANS_PORTFOLIO"));
				vo.setName(rs.getString("TRANS_NAME"));
				vo.setId(rs.getString("TRANS_ID"));
				vo.setPayRate(rs.getString("TRANS_PAYRATE"));
				vo.setContact(rs.getString("TRANS_CONTACT"));
				vo.setSoftware(rs.getString("TRANS_SOFTWARE"));
				vo.setTargLanguage(rs.getString("TRANS_TARG_LANGUAGE"));
				list.add(vo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			conn.close();
		}		
		return list;
	}

	public TransProfileVO selectAllListByNum(int num) throws SQLException {
		String sql = "select * from transProfile where trans_num=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TransProfileVO vo = null;		
		try {
			conn = TransProfileDBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				vo = new TransProfileVO();
				vo.setCode(rs.getInt("TRANS_NUM"));
				vo.setImgUrl(rs.getString("TRANS_PICURL"));
				vo.setAddress(rs.getString("TRANS_ADDRESS"));
				vo.setSrcLanguage(rs.getString("TRANS_SRC_LANGUAGE"));
				vo.setArea(rs.getString("TRANS_AREA"));
				vo.setPortfolio(rs.getString("TRANS_PORTFOLIO"));
				vo.setName(rs.getString("TRANS_NAME"));
				vo.setId(rs.getString("TRANS_ID"));
				vo.setPayRate(rs.getString("TRANS_PAYRATE"));
				vo.setContact(rs.getString("TRANS_CONTACT"));
				vo.setSoftware(rs.getString("TRANS_SOFTWARE"));
				vo.setTargLanguage(rs.getString("TRANS_TARG_LANGUAGE"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			conn.close();
		}	
		return vo;
	}

	public TransProfileVO selectAllListById(String id) throws SQLException {
		String sql = "select * from transProfile where trans_id=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TransProfileVO vo = null;		
		try {
			conn = TransProfileDBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				vo = new TransProfileVO();
				vo.setCode(rs.getInt("TRANS_NUM"));
				vo.setImgUrl(rs.getString("TRANS_PICURL"));
				vo.setAddress(rs.getString("TRANS_ADDRESS"));
				vo.setSrcLanguage(rs.getString("TRANS_SRC_LANGUAGE"));
				vo.setArea(rs.getString("TRANS_AREA"));
				vo.setPortfolio(rs.getString("TRANS_PORTFOLIO"));
				vo.setName(rs.getString("TRANS_NAME"));
				vo.setId(rs.getString("TRANS_ID"));
				vo.setPayRate(rs.getString("TRANS_PAYRATE"));
				vo.setContact(rs.getString("TRANS_CONTACT"));
				vo.setSoftware(rs.getString("TRANS_SOFTWARE"));
				vo.setTargLanguage(rs.getString("TRANS_TARG_LANGUAGE"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			conn.close();
		}	
		return vo;
	}

	public TransProfileVO selectAllListByCode(int code) throws SQLException {
		String sql = "select * from transProfile where trans_num=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TransProfileVO vo = null;		
		try {
			conn = TransProfileDBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, code);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				vo = new TransProfileVO();
				vo.setCode(rs.getInt("TRANS_NUM"));
				vo.setImgUrl(rs.getString("TRANS_PICURL"));
				vo.setAddress(rs.getString("TRANS_ADDRESS"));
				vo.setSrcLanguage(rs.getString("TRANS_SRC_LANGUAGE"));
				vo.setArea(rs.getString("TRANS_AREA"));
				vo.setPortfolio(rs.getString("TRANS_PORTFOLIO"));
				vo.setName(rs.getString("TRANS_NAME"));
				vo.setId(rs.getString("TRANS_ID"));
				vo.setPayRate(rs.getString("TRANS_PAYRATE"));
				vo.setContact(rs.getString("TRANS_CONTACT"));
				vo.setSoftware(rs.getString("TRANS_SOFTWARE"));
				vo.setTargLanguage(rs.getString("TRANS_TARG_LANGUAGE"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			conn.close();
		}	
		return vo;
	}
	
	public void updateTransProfiles(TransProfileVO vo) throws SQLException {
		String sql = "update transProfile set trans_picurl=?, trans_src_language=?, trans_area=?, trans_portfolio=?, "
				+ "trans_address=?, trans_payrate=?, trans_contact=?, "
				+ "trans_software=?, trans_targ_language=? where trans_id=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		
		try {
			conn = TransProfileDBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getImgUrl());
			pstmt.setString(2, vo.getSrcLanguage());
			pstmt.setString(3, vo.getArea());
			pstmt.setString(4, vo.getPortfolio());
			pstmt.setString(5, vo.getAddress());
			pstmt.setString(6, vo.getPayRate());
			pstmt.setString(7, vo.getContact());
			pstmt.setString(8, vo.getSoftware());
//			pstmt.setString(9, vo.getId());
			pstmt.setString(9, vo.getTargLanguage());
			pstmt.setString(10, vo.getId());
			pstmt.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			conn.close();
		}
	}

	public List<TransJobVO> selectJobList() throws SQLException {
		String sql = "select * from (select * from transjob)  where rownum<=15 order by JOBREGEDATE desc";
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;		
		List<TransJobVO> list = new ArrayList<TransJobVO>();		
		try {
			conn = TransProfileDBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				TransJobVO vo = new TransJobVO();
				
				vo.setJobNum(rs.getInt("JOBNUM"));
				vo.setJobContent(rs.getString("JOBCONTENT"));
				vo.setAgentName(rs.getString("AGENTNAME"));
				vo.setJobRegDate(rs.getTimestamp("JOBREGEDATE"));
				vo.setJobType(rs.getString("JOBTYPE"));
				list.add(vo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			conn.close();
		}		
		return list;
	}
}
