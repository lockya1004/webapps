


function Supportcheck() {
	if(document.frm.title.value.length==0){
		alert("제목을 입력해주세요");
		frm.title.focus();
		return false;
	}
	
	if(document.frm.pwd.value.length==0){
		alert("비밀번호를 입력해주세요");
		frm.pwd.focus();
		return false;
	}
	
	if (document.frm.kinds.value == "") {
		alert("분야를 선택 하세요");
		return false;
	}
	if(document.frm.email.value.length==0){
		alert("email을 입력해주세요");
		frm.email.focus();
		return false;
	}
	if(document.frm.content.value ==""){
		alert("문의내용을 입력해주세요");
		frm.content.focus();
		return false;
	}
	return true;
}
	

function search() {
	if(document.frm.keyword.value==""){
		alert("검색어를 입력하세요");
		document.frm.keyword.focus();
		return false;
	}
		return true;
}