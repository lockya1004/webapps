package com.teamfirst.project.dao;

import java.util.List;
import com.teamfirst.project.model.MyPageModel;

public interface MyPageDAO {
	MyPageModel getMyProfile(String id);
	List<MyPageModel> getReplyList(String id);
}
