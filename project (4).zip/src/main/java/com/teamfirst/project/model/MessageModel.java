package com.teamfirst.project.model;

import java.sql.Timestamp;

public class MessageModel {
	// 보내는이
	// 받는이
	// 내용
	// 보낸시각
	// 읽은 시각
	// 읽기 유무
	// 휴지통 유무
	private int num;
	private String fromid;
	private String toid;
	private String content;
	private Timestamp sendtime;
	private Timestamp readtime;
	private int readornot;
	private int waste;
	private int keep;
	private String readnull;

	public String getReadnull() {
		return readnull;
	}

	public void setReadnull(String readnull) {
		this.readnull = readnull;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getKeep() {
		return keep;
	}

	public void setKeep(int keep) {
		this.keep = keep;
	}

	public String getFromid() {
		return fromid;
	}

	public void setFromid(String fromid) {
		this.fromid = fromid;
	}

	public String getToid() {
		return toid;
	}

	public void setToid(String toid) {
		this.toid = toid;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Timestamp getSendtime() {
		return sendtime;
	}

	public void setSendtime(Timestamp sendtime) {
		this.sendtime = sendtime;
	}

	public Timestamp getReadtime() {
		return readtime;
	}

	public void setReadtime(Timestamp readtime) {
		this.readtime = readtime;
	}

	public int getReadornot() {
		return readornot;
	}

	public void setReadornot(int readornot) {
		this.readornot = readornot;
	}

	public int getWaste() {
		return waste;
	}

	public void setWaste(int waste) {
		this.waste = waste;
	}
}
