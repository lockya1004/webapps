package com.teamfirst.project.controller;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.teamfirst.project.model.MessageModel;
import com.teamfirst.project.service.LinguistService;
import com.teamfirst.project.service.MessageService;

@Controller
public class MessageController {
//메세지 폼
	
	@Inject
	private MessageService messageservice;
		
	@RequestMapping(value="/message/messageform")
	public String messageForm(){
	return "message/messageForm";	
	}
//메세지 보내기
	
	@RequestMapping(value="/message/messagesend")
	public void sendMessage(@RequestParam("message") MessageModel message) throws SQLException{
		messageservice.regMessage(message);
	} 
	
//받은 메세지 보기
	@RequestMapping(value="/message/messageview")
	public void viewMessage(Model model,@RequestParam("num") String num) throws SQLException{
		int number=Integer.parseInt(num);
		MessageModel message=messageservice.getReadMessage(number);
		messageservice.updateReadMessage(number);
	}
	
//휴지통

	
//보관함
//보낸쪽지함
//받은 쪽지함
	
	
	
}
