package com.project.action.support;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.SupportDAO;
import com.project.dto.SupportVO;

public class SupportViewAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="/Support/supportView.jsp";
		SupportDAO sdao=SupportDAO.getinstance();
		int num=Integer.parseInt(request.getParameter("num"));
		SupportVO svo=sdao.selected(num);
		request.setAttribute("support", svo);
		RequestDispatcher dispatcher=request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}

}
