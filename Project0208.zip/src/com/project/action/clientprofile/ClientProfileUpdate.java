package com.project.action.clientprofile;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.project.action.Action;
import com.project.action.support.SupportListAction;
import com.project.dao.ClientProfileDAO;
import com.project.dao.SupportDAO;
import com.project.dto.ClientProfileVO;
import com.project.dto.SupportVO;

public class ClientProfileUpdate implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String path=request.getServletContext().getRealPath("upload");
		String encType="UTF-8";
		int sizelimit=1024*1024*20;
		MultipartRequest multi=new MultipartRequest(request, path, sizelimit, encType,new DefaultFileRenamePolicy());
		//DefaultFileRenamePolicy() 파일 저장 시, 덮어쓰지 못하게 이름을 변경시켜서 중복되지 않게 해줌. 꼭 써야함..
		HttpSession session=request.getSession();
		
		String id = (String) session.getAttribute("id");
		String name = multi.getParameter("name");
		String kinds=multi.getParameter("kinds");
		System.out.println(kinds);
		String address = multi.getParameter("add");
		String image=multi.getFilesystemName("img");
		
		ClientProfileVO cpvo=new ClientProfileVO();
		cpvo.setId(id);
		cpvo.setName(name);
		cpvo.setKinds(kinds);
		cpvo.setAddress(address);
		cpvo.setImage(image);
		
		ClientProfileDAO cdao=ClientProfileDAO.getinstance();
		cdao.update(cpvo);
		
		/*String id=(String) session.getAttribute("id");
		try {
		if(id.equals("null")) {
			response.sendRedirect("/Project/ClientProfile/ClientErrorPage.jsp");
		}else if(id.equals("admin")) {
			String url="/ClientProfile/clientProfileList.jsp";
			ClientProfileDAO cpdao=ClientProfileDAO.getinstance();
			List<ClientProfileVO> list=cpdao.CpList();		
			request.setAttribute("cpList",list);
			//모든 Action은 forward한다.
			RequestDispatcher dispatchar=request.getRequestDispatcher(url);
			dispatchar.forward(request, response);
			
		}
		
		}catch(Exception e) {
			response.sendRedirect("/Project/ClientProfile/ClientErrorPage.jsp");
		}*/
		new SupportListAction().execute(request, response);
			

	}

}
