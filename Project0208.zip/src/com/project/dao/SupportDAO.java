package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.project.dto.SupportVO;
import com.project.util.DBManager;

public class SupportDAO {

	// 싱글톤패턴
	private SupportDAO() {
	}

	private static SupportDAO instance = new SupportDAO();

	public static SupportDAO getinstance() {
		return instance;
	}

	// c
	public void supportInsert(SupportVO svo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into support(num,title, kinds, id, pwd,email, content) values(support_seq.nextval,?,?,?,?,?,?)";

		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, svo.getTitle());
			pstmt.setString(2, svo.getKinds());
			pstmt.setString(3, svo.getId());
			pstmt.setString(4, svo.getPwd());
			pstmt.setString(5, svo.getEmail());
			pstmt.setString(6, svo.getContent());
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}

		}
	}
	// r

	public List<SupportVO> selectSupport() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		String sql="select * from support order by num desc";
		List<SupportVO> list=new ArrayList<SupportVO>();
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
			SupportVO svo=new SupportVO();
			svo.setNum(rs.getInt("num"));
			svo.setTitle(rs.getString("title"));
			svo.setId(rs.getString("id"));
			svo.setAnswercount(rs.getInt("answercount"));
			list.add(svo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}

	// u
	
	public void updateSupport(SupportVO svo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="update support set title=?, kinds=?, pwd=?,content=? where num=?";
		
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, svo.getTitle());
			pstmt.setString(2, svo.getKinds());
			pstmt.setString(3, svo.getPwd());
			pstmt.setString(4, svo.getContent());
			pstmt.setInt(5, svo.getNum());
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}

		}
	}

	// d
	
	public void deleteSupport(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql="delete support where num=?";
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {

			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
			
	}
	

	//searchList
	public List<SupportVO> searchSupport(String keyword) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		String sql="select * from support where title like '%'||?||'%' order by num desc";
		
		List<SupportVO> list=new ArrayList<SupportVO>();
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, keyword);
			rs=pstmt.executeQuery();
			while(rs.next()) {
			SupportVO svo=new SupportVO();
			svo.setNum(rs.getInt("num"));
			svo.setTitle(rs.getString("title"));
			svo.setId(rs.getString("id"));
			svo.setPwd(rs.getString("pwd"));
			svo.setEmail(rs.getString("email"));
			svo.setContent(rs.getString("content"));
			svo.setWritedate(rs.getTimestamp("writedate"));
			list.add(svo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}

	//수정을 위한 검색
	public SupportVO selected(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		String sql="select * from support where num=?";
		SupportVO svo = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				svo=new SupportVO();
				svo.setNum(rs.getInt("num"));
				svo.setTitle(rs.getString("title"));
				svo.setKinds(rs.getString("kinds"));
				svo.setId(rs.getString("id"));
				svo.setEmail(rs.getString("email"));
				svo.setContent(rs.getString("content"));
				svo.setWritedate(rs.getTimestamp("writedate"));
				}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		
		return svo;
	}
	
	//분야별 모음

	public List<SupportVO> menulist(String kinds) {
		String sql="select*from support where kinds=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		List<SupportVO> list=new ArrayList<SupportVO>();
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, kinds);
			rs=pstmt.executeQuery();
			while(rs.next()) {
			SupportVO svo=new SupportVO();
			svo.setNum(rs.getInt("num"));
			svo.setTitle(rs.getString("title"));
			svo.setId(rs.getString("id"));
			svo.setAnswercount(rs.getInt("answercount"));
			list.add(svo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}

}
