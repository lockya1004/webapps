/**
 * 
 */

function inputCheck(){
	var lang=new Array();
	
	if(document.frm.Address.value.length==0||document.frm.Address.value==""){
		alert("주소을 입력하세요.");
		document.frm.Address.focus();
		return false;
	}
	if(document.frm.Contact.value.length==0||document.frm.Contact.value==""){
		alert("연락처를 입력하세요.");
		document.frm.Contact.focus();
		return false;
	}
	if(document.frm.SourceLang.value==0||document.frm.SourceLang.value==""){
		alert("언어를을 입력하세요.");
		document.frm.SourceLang.focus();
		return false;
	}
	if(document.frm.TargetLang.value==0||document.frm.TargetLang.value==""){
		alert("언어를을 입력하세요.");
		document.frm.TargetLang.focus();
		return false;
	}
		
		return true;
		
}

   