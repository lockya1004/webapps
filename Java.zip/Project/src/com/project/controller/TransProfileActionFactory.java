package com.project.controller;

import com.project.action.Action;
import com.project.action.TransProfileDescAction;
import com.project.action.TransProfileMainAction;
import com.project.action.TransProfileReviewAction;
import com.project.action.TransProfileSearchAction;
import com.project.action.TransProfileUpdateAction;
import com.project.action.TransProfileWriteAction;
import com.project.action.TransProfileWriteView;

//媛앹껜瑜� 留뚮뱶�뒗 �뿭�솢

public class TransProfileActionFactory {

	private TransProfileActionFactory() {
	}

	private static TransProfileActionFactory instance = new TransProfileActionFactory();

	public static TransProfileActionFactory getInstance() {
		return instance;
	}

	public Action getAction(String command) {
		Action action = null;
		if(command.equals("portfolio_writeview")) {
			action=new TransProfileWriteView();
		}else if(command.equals("portfolio_write")) {
			action = new TransProfileWriteAction();
		} else if(command.equals("portfolio_list")) {
			action = new TransProfileMainAction();
		} else if(command.equals("portfolio_desc")) {
			action = new TransProfileDescAction();
		} else if(command.equals("portfolio_update")) {
			action = new TransProfileUpdateAction();
		} else if(command.equals("portfolio_review")) {
			action = new TransProfileReviewAction();
		} else if(command.equals("portfolio_main")) {
			action = new TransProfileMainAction();
		} else if(command.equals("portfolio_search")) {
			action = new TransProfileSearchAction();
			
		}
		
		return action;
	}
}
