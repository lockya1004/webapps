package com.project.dto;

public class Weather {
	private String baseDate;
	private String baseTime;
	private String location;
	private double t1h;
	private double SKY;
	private double REH;
	private double PTY;
	
	public double getT1h() {
		return t1h;
	}
	public void setT1h(double t1h) {
		this.t1h = t1h;
	}
	
	public String getBaseDate() {
		return baseDate;
	}
	public void setBaseDate(String baseDate) {
		this.baseDate = baseDate;
	}
	public String getBaseTime() {
		return baseTime;
	}
	public void setBaseTime(String baseTime) {
		this.baseTime = baseTime;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

	public double getSKY() {
		return SKY;
	}
	public void setSKY(double sKY) {
		SKY = sKY;
	}
	public double getREH() {
		return REH;
	}
	public void setREH(double rEH) {
		REH = rEH;
	}
	public double getPTY() {
		return PTY;
	}
	public void setPTY(double pTY) {
		PTY = pTY;
	}
	

}
