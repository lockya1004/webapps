package com.project.action.main;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.project.action.Action;
import com.project.dao.WeatherDao;
import com.project.dto.Weather;

public class WeatherPage implements Action {

	
	String Servicekey="ZgzmUM5N68VWxHZSmgXWJMzRr80jGBLcvIjerpoZiT5opkv2d1nqOWX32n2n0IMuAYDesHXqUizsUaRGsIU8Yw%3D%3D";
	
	//서울, 부산, 대구, 인천, 광주, 대전, 울산, 세종, 경기도, 강원도, 충청북도, 충청남도, 전라북도, 전라남도, 경상북도, 경상남도, 제주도, 이어도
	int[][] region= {{60,127},{98,76},{89,90},{55,124},{58,74},{67,100},{102,84},{66,103},{60,120},{73,134},{69,107},
			{68,100},{63,89},{51,67},{89,91},{91,77},{52,38},{28,8}};

	String[] Location= {"서울","부산", "대구", "인천", "광주", "대전", "울산", "세종", "경기도", "강원도", "충청북도", "충청남도", "전라북도",
								"전라남도", "경상북도", "경상남도", "제주도", "이어도"};
	
	
	public String dateloader() {
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd HHmm");
		Calendar cal=Calendar.getInstance();
		cal.setTime(date);
		cal.add(cal.HOUR, 0);
		String now=sdf.format(cal.getTime());
		return now;
	}
	
	  public String HtmlParser(String urlToRead) {
	        StringBuffer result = new StringBuffer();
	        try {
	            URL url = new URL(urlToRead);
	            InputStream is = url.openStream();
	            int ch;

	            while ((ch = is.read()) != -1) {
	                //System.out.print((char) ch);
	                result.append((char) ch);
	            }
	        } catch (MalformedURLException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return result.toString();
	    }

	  String now=dateloader();

	 public void weather(){
		 Weather wt=new Weather();
		 //url에 배열의 값들 넣어서 출력.
		 for (int j=0; j<region.length; j++) {
			 String URL = "http://newsky2.kma.go.kr/service/SecndSrtpdFrcstInfoService2/ForecastGrib?serviceKey=" +
			            Servicekey + "&base_date=" + now.substring(0, 8) + "&base_time=" + now.substring(9, 13);
			    URL+="&nx=" + region[j][0] + "&ny=" + region[j][1] +"&numOfRows=10&pageSize=10&pageNo=1&startPage=1&_type=json";
			    			    
			    String res = new WeatherPage().HtmlParser(URL.toString());
		   
				try {
					JSONParser jsonParser = new JSONParser();
			        JSONObject jsonObject = (JSONObject) jsonParser.parse(res);
			        JSONObject response = (JSONObject) jsonObject.get("response");
			        JSONObject body = (JSONObject) response.get("body");
			        JSONObject items = (JSONObject) body.get("items");
			        JSONArray item = (JSONArray) items.get("item");

			        JSONObject weatherInfo = (JSONObject) item.get(0);
			        wt.setBaseDate(weatherInfo.get("baseDate").toString());
			        wt.setBaseTime(weatherInfo.get("baseTime").toString());
			        wt.setLocation(Location[j]);
				        
				  for(int i=0; i<item.size();i++) {
					  weatherInfo=(JSONObject)item.get(i);
					  if(weatherInfo.get("category").equals("T1H")) {
						wt.setT1h(Double.parseDouble(weatherInfo.get("obsrValue").toString()));
					  }else if(weatherInfo.get("category").equals("SKY")){
						  wt.setSKY(Double.parseDouble(weatherInfo.get("obsrValue").toString()));
					  }else if(weatherInfo.get("category").equals("REH")){
						  wt.setREH(Double.parseDouble(weatherInfo.get("obsrValue").toString()));
					  }else if(weatherInfo.get("category").equals("PTY")) {
						  wt.setPTY(Double.parseDouble(weatherInfo.get("obsrValue").toString()));
					  }

				  }
				  
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
				WeatherDao dao=WeatherDao.getinstance();
			  	dao.weatherinsert(wt);
			  	
				
		 }		
	 }

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		WeatherDao wd = WeatherDao.getinstance();
		WeatherPage wp=new WeatherPage();
		wd.Delete();
		wp.weather();
		new MainPage().execute(request, response);
		
		
		
	}

	 
	
}
