package com.project.action.main;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.MainDAO;
import com.project.dao.WeatherDao;
import com.project.dto.MainVO;
import com.project.dto.Weather;

public class MainPage implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/main.jsp";
		WeatherDao wd = WeatherDao.getinstance();
		List<Weather> wlist=wd.wthlist();
		request.setAttribute("weatherlist", wlist);
		
		MainDAO mdao = MainDAO.getinstance();
		List<MainVO> list = mdao.newList();
		request.setAttribute("requestlist", list);

		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
		
	}

}
