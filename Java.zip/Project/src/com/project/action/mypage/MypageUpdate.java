package com.project.action.mypage;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.project.action.Action;
import com.project.action.mypage.MypageList;
import com.project.dao.ClientProfileDAO;
import com.project.dto.ClientProfileVO;

public class MypageUpdate implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String path=request.getServletContext().getRealPath("upload");
		String encType="UTF-8";
		int sizelimit=1024*1024*20;
		MultipartRequest multi=new MultipartRequest(request, path, sizelimit, encType,new DefaultFileRenamePolicy());
		//DefaultFileRenamePolicy() �뙆�씪 ���옣 �떆, �뜮�뼱�벐吏� 紐삵븯寃� �씠由꾩쓣 蹂�寃쎌떆耳쒖꽌 以묐났�릺吏� �븡寃� �빐以�. 瑗� �뜥�빞�븿..
		//HttpSession session=request.getSession();
		
		String id = request.getParameter("id");
		int num=Integer.parseInt(multi.getParameter("num"));
		String name = multi.getParameter("name");
		String kinds=multi.getParameter("kinds");
		String address = multi.getParameter("add");
		String image=multi.getFilesystemName("image");
		if(image==null) {
			image=multi.getParameter("images");
		}
		
		ClientProfileVO cpvo=new ClientProfileVO();
		cpvo.setNum(num);
		cpvo.setId(id);
		cpvo.setName(name);
		cpvo.setKinds(kinds);
		cpvo.setAddress(address);
		cpvo.setImage(image);
		
			ClientProfileDAO cpdao=ClientProfileDAO.getinstance();
			cpdao.update(cpvo);
			new MypageList().execute(request, response);
	
	}

}
