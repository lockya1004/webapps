package com.project.action.clientprofile;

import com.project.action.Action;

public class ClientProfileActionFactory {

	private ClientProfileActionFactory() {}
	
	private static ClientProfileActionFactory instance=new ClientProfileActionFactory();
	
	public static ClientProfileActionFactory getinstance() {
		return instance;
	}
	
	public Action getAction(String id,String command) {
		Action action=null;
		if(command.equals("cpList")) {
			action=new ClientProfileList();
		}else if(command.equals("cpWrite")) {
			action = new ClientProfileWrite();
		}else if(command.equals("cpView")) {
			action=new ClientProfileView();
		}else if(command.equals("cpUpdate")) {
			action = new ClientProfileUpdate();
		}else if(command.equals("cpDelete")) {
			action =new ClientProfileDelete();
		}else if(command.equals("cpInsert")) {
			//write �Է½�
			action =new ClientProfileInsert();
		}
		
		return action;
	}
	
}
