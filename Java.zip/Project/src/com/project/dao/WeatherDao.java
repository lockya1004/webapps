package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.project.dto.Weather;
import com.project.util.DBManager;

public class WeatherDao {
	
	
		private WeatherDao() {
		}

		private static WeatherDao instance = new WeatherDao();

		public static WeatherDao getinstance() {
			return instance;
		}
		public void weatherinsert(Weather wr){
			Connection conn = null;
			PreparedStatement pstmt = null;
			String sql = "insert into weather values(?,?,?,?,?,?,?)";

			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, wr.getBaseDate());
				pstmt.setString(2, wr.getBaseTime());
				pstmt.setString(3, wr.getLocation());
				pstmt.setDouble(4, wr.getT1h());
				pstmt.setDouble(5, wr.getSKY());
				pstmt.setDouble(6, wr.getREH());
				pstmt.setDouble(7, wr.getPTY());
				pstmt.executeUpdate();

			} catch (Exception e) {
				e.printStackTrace();
			} finally {

				try {
					conn.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}

			}
	}
		public List<Weather> wthlist() {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs=null;
			String sql="select * from weather";
			List<Weather> list=new ArrayList<Weather>();
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				rs=pstmt.executeQuery();
				while(rs.next()) {
				Weather wr=new Weather();
				wr.setBaseDate(rs.getString("basedate"));
				wr.setBaseTime(rs.getString("basetime"));
				wr.setLocation(rs.getString("location"));
				wr.setT1h(rs.getDouble("t1h"));
				wr.setSKY(rs.getDouble("sky"));
				wr.setREH(rs.getDouble("reh"));
				wr.setPTY(rs.getDouble("pty"));
			
				list.add(wr);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {

				try {
					conn.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			return list;
		}
		
		public void Delete() {
			Connection conn = null;
			PreparedStatement pstmt = null;
			String sql="delete from weather";
			
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.executeUpdate();
			}catch(Exception e) {
				e.printStackTrace();
			}finally {

				try {
					conn.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
			

}
