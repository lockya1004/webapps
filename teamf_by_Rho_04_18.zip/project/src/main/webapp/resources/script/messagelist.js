/**
 * 
 */




function allcheck() {

		$("#sel").click(function() {
			if ($("#sel").is(":checked")) {
				$("input[name=select]:checkbox").attr("checked", true);
			} else {
				$("input[name=select]:checkbox").attr("checked", false);
			}
		});

	}

	
function button(id) {
	 var data=0;
     var id=id;
     
     alert(id);
	 $('input:checkbox[name=select]').each(function() {
	
	     if(this.checked == true){ //값 비교
			if(data==0){
	         data=this.value;
			}else{
			data+=","+this.value;
			}
	      }
	 });
	 location.href="message/btmu?btnid="+id+"&num="+data;
	 
}

