package com.teamfirst.project.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartRequest;

import com.teamfirst.project.model.ClientModel;
import com.teamfirst.project.service.ClientService;

@Controller
public class ClientController {

	@Inject
	private ClientService clientService;

	@RequestMapping("client/go.register")
	public String clientRegister(HttpSession session, Model model) throws SQLException {
		if (session.getAttribute("userid") == null) {
			return "member/login";
		} else {

			return "client/clientRegister";
		}

	}

	@RequestMapping(value = "client/go.insert", method = RequestMethod.POST)
	public String clientInsert(@RequestParam("uploadFile") MultipartFile file, MultipartHttpServletRequest request,
			ClientModel model) throws Exception {

		HttpSession session = request.getSession();
		String path = session.getServletContext().getRealPath("/");

		String relpath = path + "resources\\files\\" + file.getOriginalFilename();
		System.out.println("path: " + relpath);

		System.out.println(file.getOriginalFilename());

		File serverFile = new File(relpath);
		file.transferTo(serverFile);

		model.setImage(file.getOriginalFilename());
		clientService.regClient(model);

		return "redirect:/client/go.list";
	}

	@RequestMapping("client/go.list")
	public String listClient(Model model) throws SQLException {

		List<ClientModel> list = clientService.listClient();
		model.addAttribute("clientlist", list);

		return "client/clientSearch";
	}

	@RequestMapping("client/go.search")
	public String reqList(Model model, HttpServletRequest request, String keyword) throws SQLException {
		keyword = request.getParameter("keyword");
		List<ClientModel> searchlist;
		if (keyword == null) {
			searchlist = clientService.listClient();
		} else {
			searchlist = clientService.searchClient(keyword);
		}
		System.out.println(keyword);

		model.addAttribute("clientlist", searchlist);
		return "client/clientSearch";
	}

	@RequestMapping(value = "client/go.view")
	public String clientview(Model model, @RequestParam("num") String num) throws SQLException {
		int number = Integer.parseInt(num);
		ClientModel clientmodel = clientService.selectClient(number);
		model.addAttribute("clientlist", clientmodel);

		return "client/clientView";
	}

}
