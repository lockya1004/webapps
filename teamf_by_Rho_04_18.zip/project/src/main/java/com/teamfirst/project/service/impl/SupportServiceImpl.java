package com.teamfirst.project.service.impl;

import java.util.List;


import javax.inject.Inject;

import org.springframework.stereotype.Service;
import com.teamfirst.project.dao.SupportDAO;
import com.teamfirst.project.model.SupportModel;
import com.teamfirst.project.service.SupportService;

@Service("supportService")
public class SupportServiceImpl implements SupportService{

/*	@Resource(name="supportDAO")
	private SupportDAO supportDAO;*/
	@Inject
	private SupportDAO supportDAO;

	@Override
	public int regSupport(SupportModel model) {
		return supportDAO.regSupport(model);
	}

	@Override
	public List<SupportModel> getSupportList() {
		return supportDAO.getSupportList();
	}

	@Override
	public int updateSupport(SupportModel model) {
		return supportDAO.updateSupport(model);
	}

	@Override
	public int delSupport(int num) {
		return supportDAO.delSupport(num);
	}

	@Override
	public List<SupportModel> searchSupport(String keyword) {
		return supportDAO.searchSupport(keyword);
	}

	@Override
	public SupportModel getSelectByNum(int num) {
		return supportDAO.getSelectByNum(num);
	}

	@Override
	public List<SupportModel> getMenuList(String kinds) {
		return supportDAO.getMenuList(kinds);
	}	
}
