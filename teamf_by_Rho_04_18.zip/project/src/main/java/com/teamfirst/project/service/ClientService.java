package com.teamfirst.project.service;

import java.sql.SQLException;
import java.util.List;

import com.teamfirst.project.model.ClientModel;

public interface ClientService {
	int regClient(ClientModel model) throws SQLException;

	//등록, 리스트, 수정, 삭제, 리스트(넘버)
	List<ClientModel> listClient()  throws SQLException;
	ClientModel selectClient(int num)  throws SQLException;
	int updateClient(ClientModel client)  throws SQLException;
	int deleteClient(int num)  throws SQLException;
	List<ClientModel> searchClient(String keyword) throws SQLException;
	
	

/*    int regContent(Map<String, Object> paramMap);   
    int getContentCnt(Map<String, Object> paramMap);     
    List<Board> getContentList(Map<String, Object> paramMap);     
    Board getContentView(Map<String, Object> paramMap);     
    int regReply(Map<String, Object> paramMap);     
    List<BoardReply> getReplyList(Map<String, Object> paramMap);     
    int delReply(Map<String, Object> paramMap);     
    int getBoardCheck(Map<String, Object> paramMap);     
    int delBoard(Map<String, Object> paramMap);*/
}
