package com.teamfirst.project.dao;

import java.util.List;
import com.teamfirst.project.model.RequestModel;

public interface RequestDAO {
	List<RequestModel> getAllRequest();
	int regRequest(RequestModel model);
	int updateReadCount(String num);
	RequestModel getRequestDetailsByNum(String num);
	int updateRequest(RequestModel model);
	RequestModel checkPassWord(String pass, String num);
	int delRequest(String num);
	List<RequestModel> getRequestList();
}
