package com.project.util;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBManager {
	
public static Connection getConnection() {
	Connection conn=null;
	try {
		Context initContext = new InitialContext();
		Context envContext  = (Context)initContext.lookup("java:/comp/env");
		DataSource ds = (DataSource)envContext.lookup("jdbc/myoracle");//바라보는 거... server.xml에 있는 resouce의 name의 이름과 동일하게 맞춰줘야 함. 
		conn = ds.getConnection();
		System.out.println();
	//커넥션 풀 : 다수의 사람들이 방문할 수 있도록 해준다.
	} catch (Exception e) {
		e.printStackTrace();
		System.out.println("connection 오류");
	}
	return conn;
}
}
