package com.project.action;

import com.project.action.re.JobListAction;
import com.project.action.re.ReCheckPassAction;
import com.project.action.re.ReCheckPassFormAction;
import com.project.action.re.ReDeleteAction;
import com.project.action.re.ReUpdateAction;
import com.project.action.re.ReUpdateFormAction;
import com.project.action.re.ReViewAction;
import com.project.action.re.ReWriteAction;
import com.project.action.re.ReWriteFormAction;

public class ReActionFactory {
	
	private static ReActionFactory ins = new ReActionFactory();
	
	private ReActionFactory() {
		super();
	}
	
	public static ReActionFactory getIns() {
		return ins;
	}
	
	public Action getAction(String command) {
		Action action = null;
		System.out.println("ActionFactory :"+command);
		

		if(command.equals("re_write_form")) {
			action = new ReWriteFormAction();
		}
		//
		else if(command.equals("re_write")) {
			action = new ReWriteAction();
		}
		
		else if(command.equals("re_view")) {
			action = new ReViewAction();
		}
		
		else if(command.equals("re_check_pass_form")) {
			action = new ReCheckPassFormAction();
		}
		
		else if(command.equals("re_check_pass")) {
			action = new ReCheckPassAction();
		}
		
		else if(command.equals("re_update_form")) {
			action = new ReUpdateFormAction();
		}
		
		else if(command.equals("re_update")){
			action = new ReUpdateAction();
		}
		
		else if(command.equals("re_delete")) {
			action = new ReDeleteAction();
			
		}else if(command.equals("joblist")) {
			action =new JobListAction();
		}
		
		return action;
	}
}







