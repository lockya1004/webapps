package com.project.action.support;

import com.project.action.Action;

public class SupportActionFactory {

	private SupportActionFactory() {}
	
	private static SupportActionFactory instance=new SupportActionFactory();
	
	public static SupportActionFactory getinstance() {
		return instance;
	}
	
	public Action getAction(String command) {
		Action action = null;
		
		if(command.equals("supportList")) {
			action=new SupportListAction();
		}else if(command.equals("supportInsert")){
			action=new SupportInsertAction();
		}else if(command.equals("supportWrite")) {
			action=new SupportWriteAction();	//action=new SupportViewAction();		
		}else if(command.equals("supportView")) {
			System.out.println(command);
			action=new SupportViewAction();
		} else if(command.equals("supportUpdate")) {
			action=new SupportUpdateAction();			
		}else if(command.equals("supportDelete")) {
			action = new SupportDeleteAction();
			
		}else if(command.equals("supportSearch")) {
			action = new SupportSearchAction();
			
		}else if(command.equals("password")) {
			action=new SupportPasswordAction();
		}else if(command.equals("menu")){
			action=new SupportMenuAction();
		}
		
		return action;

	}	
	
	
	
	}
