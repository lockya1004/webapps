package com.project.action.support;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.SupportDAO;
import com.project.dto.SupportVO;

public class SupportListAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="/Support/supportList.jsp";
		SupportDAO sdao=SupportDAO.getinstance();
		List<SupportVO> supportlist=sdao.selectSupport();		
		request.setAttribute("supportList", supportlist);

		//모든 Action은 forward한다.
		RequestDispatcher dispatchar=request.getRequestDispatcher(url);
		dispatchar.forward(request, response);
		
	}

}
