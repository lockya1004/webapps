package com.project.action.main;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MemberDAO;
import com.project.dto.MemberVO;

public class JoinSuccess implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//한글이 깨지지않게 인코딩 설정
		request.setCharacterEncoding("UTF-8");
		
		// 폼에서 입력한 회원 정보를 얻어옴
		String name = request.getParameter("name");
		String userid = request.getParameter("userid");
		String pwd = request.getParameter("pwd");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String admin = request.getParameter("admin");
		
		
		//회원정보를 저장할 객체를 생성
		MemberVO mvo = new MemberVO();
		//MemberVO 객체인 mvo에 회원 가입 옾에서 입력 받은 데이터를 저장합니다.
		mvo.setName(name);
		mvo.setUserid(userid);
		mvo.setPwd(pwd);
		mvo.setEmail(email);
		mvo.setPhone(phone);
		mvo.setAdmin(Integer.parseInt(admin));
		
		
		
		
		MemberDAO mdao = MemberDAO.getInstance();
		int re = mdao.insertMember(mvo);
		
		
	    HttpSession se = request.getSession();
	    
	    
	    if(re==1) {
	    	se.setAttribute(userid, mvo.getUserid());
	    	request.setAttribute("message", "회원 가입에 성공했습니다!!");
	    }else {
	    	request.setAttribute("message", "회원 가입 실패!.");
	    }
	
	    RequestDispatcher dis = request.getRequestDispatcher("member/login.jsp");
	    dis.forward(request, response);
	    
	}


}
