package com.project.action.transprofile;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.TransProfileDAO;
import com.project.dto.TransProfileVO;

public class TransProfileReviewAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/profile/transProfileUpdate.jsp";
//		int code = Integer.parseInt(request.getParameter("Code"));
		String id = request.getParameter("Id");
		request.setCharacterEncoding("utf-8");
		TransProfileDAO pDao = TransProfileDAO.getInstance();
		TransProfileVO profileReview;
		try {
			profileReview = pDao.selectAllListById(id);
			request.setAttribute("profileReview", profileReview);
			RequestDispatcher dispatcher = request.getRequestDispatcher(url);	
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}