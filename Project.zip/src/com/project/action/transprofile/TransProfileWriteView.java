package com.project.action.transprofile;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;

public class TransProfileWriteView implements Action{
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url=null;
		HttpSession session=request.getSession();
		Object id = session.getAttribute("userid");
		if(id==null) {
			url="/re/onlymember.jsp";
			}else {
			url = "/profile/transProfileWrite.jsp";
			}
		
		request.getRequestDispatcher(url).forward(request, response);
		
	}

}
