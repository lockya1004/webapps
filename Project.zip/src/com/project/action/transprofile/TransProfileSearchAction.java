package com.project.action.transprofile;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.TransProfileDAO;
import com.project.dto.TransProfileVO;

public class TransProfileSearchAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url="/profile/transProfileSearch.jsp";
		String keyword=request.getParameter("keyword");
		TransProfileDAO tdao=TransProfileDAO.getInstance();
		List<TransProfileVO> translist=tdao.searchProfile(keyword);
		request.setAttribute("keyword", keyword);
		request.setAttribute("translist", translist);
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}

}
