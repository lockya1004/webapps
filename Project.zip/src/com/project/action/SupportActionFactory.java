package com.project.action;

import com.project.action.support.SupportDeleteAction;
import com.project.action.support.SupportInsertAction;
import com.project.action.support.SupportListAction;
import com.project.action.support.SupportMenuAction;
import com.project.action.support.SupportSearchAction;
import com.project.action.support.SupportUpdateAction;
import com.project.action.support.SupportViewAction;
import com.project.action.support.SupportWriteAction;

public class SupportActionFactory {

	private SupportActionFactory() {}
	
	private static SupportActionFactory instance=new SupportActionFactory();
	
	public static SupportActionFactory getinstance() {
		return instance;
	}
	
	public Action getAction(String command) {
		Action action = null;
		if(command.equals("supportList")){
			action=new SupportListAction();
		}else if(command.equals("supportInsert")){
			action=new SupportInsertAction();
		}else if(command.equals("supportWrite")) {
			action=new SupportWriteAction();	//action=new SupportViewAction();		
		}else if(command.equals("supportView")) {
			action=new SupportViewAction();
		} else if(command.equals("supportUpdate")) {
			action=new SupportUpdateAction();			
		}else if(command.equals("supportDelete")) {
			action = new SupportDeleteAction();
			
		}else if(command.equals("supportSearch")) {
			action = new SupportSearchAction();
		}else if(command.equals("menu")){
			action=new SupportMenuAction();
		}
		
		return action;

	}	
	
	
	
	}
