package com.project.action;

import com.project.action.clientprofile.ClientProfileDelete;
import com.project.action.clientprofile.ClientProfileInsert;
import com.project.action.clientprofile.ClientProfileList;
import com.project.action.clientprofile.ClientProfileUpdate;
import com.project.action.clientprofile.ClientProfileView;
import com.project.action.clientprofile.ClientProfileWrite;

public class ClientProfileActionFactory {

	private ClientProfileActionFactory() {}
	
	private static ClientProfileActionFactory instance=new ClientProfileActionFactory();
	
	public static ClientProfileActionFactory getinstance() {
		return instance;
	}
	
	public Action getAction(String command) {
		Action action=null;
		if(command.equals("cpList")) {
			action=new ClientProfileList();
		}else if(command.equals("cpWrite")) {
			action = new ClientProfileWrite();
		}else if(command.equals("cpView")) {
			action=new ClientProfileView();
		}else if(command.equals("cpUpdate")) {
			action = new ClientProfileUpdate();
		}else if(command.equals("cpDelete")) {
			action =new ClientProfileDelete();
		}else if(command.equals("cpInsert")) {
			action =new ClientProfileInsert();
		}
		
		return action;
	}
	
}
