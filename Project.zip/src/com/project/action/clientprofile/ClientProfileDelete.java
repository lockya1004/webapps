package com.project.action.clientprofile;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.ClientProfileDAO;

public class ClientProfileDelete implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id=request.getParameter("id");
		ClientProfileDAO cdao=ClientProfileDAO.getinstance();
		cdao.delete(id);
		new ClientProfileList().execute(request, response);
		
		//HttpSession session=request.getSession();
		/*String id=(String) session.getAttribute("id");
		try {
		if(id.equals("null")) {
			response.sendRedirect("/Project/ClientProfile/ClientErrorPage.jsp");
		}else if(id.equals("admin")) {
			String url="/ClientProfile/clientProfileList.jsp";
			ClientProfileDAO cpdao=ClientProfileDAO.getinstance();
			List<ClientProfileVO> list=cpdao.CpList();		
			request.setAttribute("cpList",list);
			//모든 Action은 forward한다.
			RequestDispatcher dispatchar=request.getRequestDispatcher(url);
			dispatchar.forward(request, response);
			
		}
		
		}catch(Exception e) {
			response.sendRedirect("/Project/ClientProfile/ClientErrorPage.jsp");
		}*/

	}

}
