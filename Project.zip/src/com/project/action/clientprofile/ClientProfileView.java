package com.project.action.clientprofile;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.ClientProfileDAO;
import com.project.dto.ClientProfileVO;


public class ClientProfileView implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ClientProfileDAO cpdao=ClientProfileDAO.getinstance();
		//String id=request.getParameter("id");
		String id="admin";
		int num=Integer.parseInt(request.getParameter("num"));
		ClientProfileVO cvo=cpdao.selected(num);
		if(id.equals(cvo.getId())) {
			request.setAttribute("cprofilelist", cvo);
			String url="/clientProfile/clientProfileView.jsp";
			RequestDispatcher dispatcher=request.getRequestDispatcher(url);
			dispatcher.forward(request, response);
		}else {
			request.setAttribute("cprofilelist", cvo);
			String url="/clientProfile/clientView.jsp";
			RequestDispatcher dispatcher=request.getRequestDispatcher(url);
			dispatcher.forward(request, response);
		}
		

	}

}

