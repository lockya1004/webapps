package com.project.action.clientprofile;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.project.action.Action;
import com.project.action.mypage.MypageList;
import com.project.dao.ClientProfileDAO;
import com.project.dto.ClientProfileVO;

public class ClientProfileUpdate implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String path=request.getServletContext().getRealPath("upload");
		String encType="UTF-8";
		int sizelimit=1024*1024*20;
		MultipartRequest multi=new MultipartRequest(request, path, sizelimit, encType,new DefaultFileRenamePolicy());
		//DefaultFileRenamePolicy() 파일 저장 시, 덮어쓰지 못하게 이름을 변경시켜서 중복되지 않게 해줌. 꼭 써야함..
		//HttpSession session=request.getSession();
		
		//String id = (String) session.getAttribute("id");
		String id="admin";
		int num=Integer.parseInt(multi.getParameter("num"));
		
		String name = multi.getParameter("name");
		String kinds=multi.getParameter("kinds");
		String address = multi.getParameter("add");
		String image=multi.getFilesystemName("image");
		if(image==null) {
			image=multi.getParameter("images");
		}
		
		ClientProfileVO cpvo=new ClientProfileVO();
		cpvo.setNum(num);
		cpvo.setId(id);
		cpvo.setName(name);
		cpvo.setKinds(kinds);
		cpvo.setAddress(address);
		cpvo.setImage(image);
		
		try {
			if(id.equals("admin")) {
			ClientProfileDAO cpdao=ClientProfileDAO.getinstance();
			cpdao.update(cpvo);
			new ClientProfileList().execute(request, response);
		}
		
		}catch(Exception e) {
			new MypageList().execute(request, response);
			
			
			
		}
	
			

	}

}
