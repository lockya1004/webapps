package com.project.action.re;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.action.Action;
import com.project.dao.MemberDAO;
import com.project.dto.MemberVO;

public class ReWriteFormAction implements Action{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		Object userid = session.getAttribute("userid");
		String id=(String) userid;
		String url=null;
		if(id==null) {
		url="/re/onlymember.jsp";
		}else {
		url = "/re/reWrite.jsp";
		MemberDAO mdao=MemberDAO.getInstance();
		MemberVO vo=mdao.getMember(id);
		request.setAttribute("vo", vo);
		}
		RequestDispatcher dis = request.getRequestDispatcher(url);
		dis.forward(request, response);
		
	}
}
