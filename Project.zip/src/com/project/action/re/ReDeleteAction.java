package com.project.action.re;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.ReDAO;

public class ReDeleteAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		 String num = request.getParameter("num");
		 
		 ReDAO rdao = ReDAO.getins();
		 rdao.deleteRe(num);
		 
		 new JobListAction().execute(request, response);
		 
		
	}
}






