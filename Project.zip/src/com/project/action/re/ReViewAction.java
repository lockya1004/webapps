package com.project.action.re;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.ReDAO;
import com.project.dto.ReVO;

public class ReViewAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String url = "/re/reView.jsp";
		
		String num = request.getParameter("num");
		
		ReDAO rdao = ReDAO.getins();
		
		rdao.updateReadCont(num);
		
		ReVO rvo = rdao.selectOneReByNum(num);
		
		request.setAttribute("re", rvo);
		
		RequestDispatcher dis = request.getRequestDispatcher(url);
				dis.forward(request, response);
	}
}





