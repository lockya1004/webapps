package com.project.action.re;

import java.io.IOException;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.action.Action;
import com.project.dao.ReDAO;
import com.project.dto.ReVO;

public class ReUpdateAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		ReVO rvo = new ReVO();
		
		rvo.setNum(Integer.parseInt(request.getParameter("num")));
		rvo.setPass(request.getParameter("pass"));
		rvo.setName(request.getParameter("name"));
		rvo.setUserid(request.getParameter("userid"));
		rvo.setEmail(request.getParameter("email"));
		rvo.setTitle(request.getParameter("title"));
		rvo.setLanguage(request.getParameter("language"));
		rvo.setContent(request.getParameter("content"));
		rvo.setRefile(request.getParameter("reflie"));
		rvo.setDeadline(Timestamp.valueOf(request.getParameter("deadline")));
		rvo.setCash(request.getParameter("cash"));
		
		ReDAO rdao = ReDAO.getins();
		rdao.updateRe(rvo);
		
		new JobListAction().execute(request, response);
	}
}













