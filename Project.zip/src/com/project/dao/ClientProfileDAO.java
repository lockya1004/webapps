package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.project.dto.ClientProfileVO;
import com.project.util.DBManager;

public class ClientProfileDAO {

	// 싱글톤
	private ClientProfileDAO() {
	}

	private static ClientProfileDAO instance = new ClientProfileDAO();

	public static ClientProfileDAO getinstance() {
		return instance;
	}

	// c

	public void CpWrite(ClientProfileVO cvo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into clientprofile(num, id, name, kinds, address, image) values(cp_seq.nextval,?,?,?,?,?)";
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cvo.getId());
			pstmt.setString(2, cvo.getName());
			pstmt.setString(3, cvo.getKinds());
			pstmt.setString(4, cvo.getAddress());
			pstmt.setString(5, cvo.getImage());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	// r

	public List<ClientProfileVO> CpList(ClientProfileVO cvo) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from clientprofile order by num";
		List<ClientProfileVO> list = new ArrayList<ClientProfileVO>();
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ClientProfileVO vo = new ClientProfileVO();
				vo.setNum(rs.getInt("num"));
				vo.setId(rs.getString("id"));
				vo.setName(rs.getString("name"));
				vo.setAddress(rs.getString("address"));
				vo.setImage(rs.getString("image"));
				vo.setWritedate(rs.getTimestamp("writedate"));
				list.add(vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}

	// view

	// u

	// d

}
