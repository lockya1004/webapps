package com.project.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.project.dto.ReVO;
import com.project.util.DBManager;


public class ReDAO {

	private ReDAO() {
		
	}

	private static ReDAO ins = new ReDAO();
	
	public static ReDAO getins() {
		return ins;
	}
		
	
	public List<ReVO> selectAllRe(){
		
	   String sql = "select * from re order by num desc";
	   
	   List<ReVO> list = new ArrayList<ReVO>();
	   Connection conn = null;
	   Statement stmt = null;
	   ResultSet rs = null;
	   
	   try {
		conn = DBManager.getConnection();
		stmt = conn.createStatement();
		rs = stmt.executeQuery(sql);
		
		while(rs.next()) {
			
			ReVO revo = new ReVO();
			revo.setNum(rs.getInt("num"));
			revo.setPass(rs.getString("pass"));
			revo.setName(rs.getString("name"));
			revo.setUserid(rs.getString("userid"));
			revo.setEmail(rs.getString("email"));
			revo.setTitle(rs.getString("title"));
			revo.setLanguage(rs.getString("language"));
			revo.setContent(rs.getString("content"));
			revo.setRefile(rs.getString("refile"));
			revo.setDeadline(rs.getDate("deadline"));
			revo.setCash(rs.getString("cash"));
			revo.setReadcont(rs.getInt("readcont"));
			revo.setWrirdate(rs.getTimestamp("wrirdate"));
			revo.setNow(rs.getString("now"));
			
			list.add(revo);
			
		}
	} catch (Exception e) {
		e.printStackTrace();
	}finally {
		DBManager.close(conn, stmt, rs);
	}
	   return list;
	}
	
	
	
	
	
	public void insertRe(ReVO rvo) {
		String sql = "insert into re("
				+ "num, pass, name, userid, email, title, language, content, refile, deadline, cash)"
				+ "values(re_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBManager.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, rvo.getPass());
			pstmt.setString(2, rvo.getName());
			pstmt.setString(3, rvo.getUserid());
			pstmt.setString(4, rvo.getEmail());
			pstmt.setString(5, rvo.getTitle());
			pstmt.setString(6, rvo.getLanguage());
			pstmt.setString(7, rvo.getContent());
			pstmt.setString(8, rvo.getRefile());
			java.util.Date date=rvo.getDeadline();
			java.sql.Date sqldate=new Date(date.getTime());
		
			pstmt.setDate(9, sqldate);
			pstmt.setString(10, rvo.getCash());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(conn, pstmt);
		}
	}
	
	
	
	
	
	public void updateReadCont(String num) {
		String sql = "update re set readcont=readcont+1 where num=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBManager.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, num);
			
			pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			DBManager.close(conn, pstmt);
		}
	}
	
	
	
	
	
	//게시판 글 상세 내용 보기 :글번호로 찾아온다.: 실패 null,
	public ReVO selectOneReByNum(String num) {
		String sql = "select * from re where num = ?";
		
		ReVO rvo = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs  = null;
		
		try {
			conn = DBManager.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, num);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				rvo = new ReVO();
				
				rvo.setNum(rs.getInt("num"));
				rvo.setPass(rs.getString("pass"));  
				rvo.setName(rs.getString("name"));
				rvo.setUserid(rs.getString("userid"));
				rvo.setEmail(rs.getString("email"));
				rvo.setTitle(rs.getString("title"));
				rvo.setLanguage(rs.getString("language"));
				rvo.setContent(rs.getString("content"));
				rvo.setRefile(rs.getString("refile"));
				rvo.setDeadline(rs.getTimestamp("deadline"));
				rvo.setCash(rs.getString("cash"));
				rvo.setReadcont(rs.getInt("readcont"));
				rvo.setWrirdate(rs.getTimestamp("wrirdate"));	
				rvo.setNow(rs.getString("now"));
			}
			
			} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(conn, pstmt, rs);
		}
		return rvo;
	}
	
	
	
	
	
	public void updateRe(ReVO rvo) {
		String sql = "update re set pass=?, name=?, userid=?, "
				+ "email=?, title=?, language=?, content=?,"
				+ "reflie=?, deadline=?, cash=? where num=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, rvo.getPass());
			pstmt.setString(2, rvo.getName());
			pstmt.setString(3, rvo.getUserid());
			pstmt.setString(4, rvo.getEmail());
			pstmt.setString(5, rvo.getTitle());
			pstmt.setString(6, rvo.getLanguage());
			pstmt.setString(7, rvo.getContent());
			pstmt.setString(8, rvo.getRefile());
			java.util.Date date=rvo.getDeadline();
			java.sql.Date sqldate=new Date(date.getTime());
		
			pstmt.setDate(9, sqldate);
			pstmt.setString(10, rvo.getCash());
			pstmt.setInt(11, rvo.getNum());
			
			pstmt.executeQuery();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(conn, pstmt);
		}
	}
	
	
	
	
	
	public ReVO checkPassWord(String pass, String num) {
		String sql = "select * from re where pass=? and num=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ReVO rvo = null;
		
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, pass);
			pstmt.setString(2, num);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				rvo = new ReVO();
				
				rvo.setNum(rs.getInt("num"));
				rvo.setPass(rs.getString("pass"));  
				rvo.setName(rs.getString("name"));
				rvo.setUserid(rs.getString("userid"));
				rvo.setEmail(rs.getString("email"));
				rvo.setTitle(rs.getString("title"));
				rvo.setLanguage(rs.getString("language"));
				rvo.setContent(rs.getString("content"));
				rvo.setRefile(rs.getString("reflie"));
				rvo.setDeadline(rs.getTimestamp("deadline"));
				rvo.setCash(rs.getString("cash"));
				rvo.setReadcont(rs.getInt("readcont"));
				rvo.setWrirdate(rs.getTimestamp("wrirdate"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rvo;
	}
	
	
	
	
	
	
	public void deleteRe(String num) {
		String sql = "delete re where num=?";
				
		Connection conn = null;
		PreparedStatement pstmt = null;
				
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, num);
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public List<ReVO> listRe(){ 
		
		List<ReVO> list=new ArrayList<ReVO>();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=DBManager.getConnection();
			String sql="select * from RE order by num desc";
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				ReVO vo=new ReVO();
				vo.setNum(rs.getInt("num"));
				vo.setTitle(rs.getString("title"));
				vo.setLanguage(rs.getString("language"));
				vo.setWrirdate(rs.getTimestamp("wrirdate"));
				vo.setUserid(rs.getString("userid"));
				vo.setNow(rs.getString("now"));
				list.add(vo);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		
		}finally {
			try {
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		
		
		return list;
		}


	
	
}