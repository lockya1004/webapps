package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.project.dto.MypageVO;
import com.project.util.DBManager;

public class MypageDAO {
	
	// 싱글톤
		private MypageDAO(){
		}

		private static MypageDAO instance = new MypageDAO();

	public static MypageDAO getinstance() {
		return instance;
	}

	//r
	public MypageVO getist(String id) {
		String sql="select c.num, c.image, c.id, m.name, c.kinds, m.email, c.address " + 
				"from clientprofile c, member m where c.id=?";
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		MypageVO vo=null;
		try {
		conn=DBManager.getConnection();
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs=pstmt.executeQuery();
		if(rs.next()) {
			vo=new MypageVO();
			vo.setNum(rs.getInt("num"));
			vo.setImage(rs.getString("image"));
			vo.setUserid(rs.getString("id"));
			vo.setName(rs.getString("name"));
			vo.setKinds(rs.getString("kinds"));
			vo.setEmail(rs.getString("email"));
			vo.setAddress(rs.getString("address"));
		}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		return vo;
	}
	
	public List<MypageVO> boardList(String id) {
		String sql="select * from re where userid=?";
		List<MypageVO> list=new ArrayList<MypageVO>();
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			conn=DBManager.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();
			while (rs.next()) {
				MypageVO mvo=new MypageVO();
				mvo.setNum(rs.getInt("num"));
				mvo.setTitle(rs.getString("title"));
				mvo.setLanguage(rs.getString("language"));
				mvo.setRequestdate(rs.getTimestamp("wrirdate"));
				mvo.setDeadline(rs.getTimestamp("deadline"));
				mvo.setNow(rs.getString("now"));
				list.add(mvo);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return list;
	}
	
	
}
