package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.project.dto.Weather;
import com.project.util.DBManager;

public class WeatherDao {

	private WeatherDao() {
	};

	private static WeatherDao instance = new WeatherDao();

	public static WeatherDao getinstance() {
		return instance;
	}

	public void insertWeather(Weather w) {
		String sql = "insert into weather values(?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, w.getLocation());
			pstmt.setDouble(2, w.getTemp());
			pstmt.setString(3, w.getIcon());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
	}

	public void deleteWeather() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			String sql = "delete from weather";
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public List<Weather> selectWeather() {
		List<Weather> list = new ArrayList<Weather>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			String sql = "select * from weather";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Weather w=new Weather();
				w.setLocation(rs.getString("location"));
				w.setTemp(rs.getDouble("temp"));
				w.setIcon(rs.getString("icon"));
				list.add(w);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return list;
	}

}
