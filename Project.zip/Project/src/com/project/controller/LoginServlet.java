package com.project.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.RequestWrapper;

import com.project.dao.MemberDAO;
import com.project.dto.MemberVO;

import sun.rmi.server.Dispatcher;


@WebServlet("/login.do")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public LoginServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String url ="member/Login.jsp";
		HttpSession se = request.getSession();// 세션 지정하는거
		
		if(se.getAttribute("loginUser") !=null){//이미 로그인 된 사용자이면
			url="main.jsp"; //메인 페이지로 이동
		}
		RequestDispatcher dis = request.getRequestDispatcher(url);
		
		dis.forward(request, response);
		
		
		RequestDispatcher ds = request.getRequestDispatcher("member/Login.jsp");
		ds.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String url = "member/Login.jsp";
		String id = request.getParameter("userid");
		String pw = request.getParameter("pwd");
		
		MemberDAO dao = MemberDAO.getInstance();
		int r = dao.userCheck(id, pw);
		
		if(r==1) {
			MemberVO vo = dao.getMember(id);
			HttpSession se = request.getSession();
			se.setAttribute("loginUser", vo);
			request.setAttribute("message", "회원가입에 성공하였습니다");
			url = "main.jsp";
		}else if(r==0) {
			request.setAttribute("message", "비밀번호가 맞지 않습니다.");	
		}else if(r==-1) {
			request.setAttribute("message", "존재하지 않는 회원입니다");
		}
		RequestDispatcher ds = request.getRequestDispatcher(url);
		ds.forward(request, response);
		
	}

}
