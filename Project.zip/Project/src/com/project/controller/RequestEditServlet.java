package com.project.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.MemberDAO;
import com.project.dao.RequestDAO;
import com.project.dto.MemberVO;
import com.project.dto.RequestVO;


@WebServlet("/requestEdit.do")
public class RequestEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RequestEditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String userid = request.getParameter("userid");
		RequestDAO rdao = RequestDAO.getins();
		
		RequestVO rvo = rdao.getRequest(userid);
		request.setAttribute("rvo", rvo);
		
		
		RequestDispatcher ds = request.getRequestDispatcher("member/RequestEdit.jsp");
		ds.forward(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		//한글 깨짐을 방지
				
		request.setCharacterEncoding("UTF-8");
		
		String name = request.getParameter("name");
		String userid = request.getParameter("userid");
		String title = request.getParameter("title");
		String language = request.getParameter("language");
		String content = request.getParameter("content");
		
		RequestVO rvo = new RequestVO();
		rvo.setName(name);
		rvo.setUserid(userid);
		rvo.setTitle(title);
		rvo.setLanguage(language);
		rvo.setContent(content);
		
		RequestDAO rdao = RequestDAO.getins();
		rdao.updateRequest(rvo);
		
		response.sendRedirect("login.do");
		
		/*response.sendRedirect("requestIn.do");*/
	
	}

}
