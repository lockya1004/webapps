package com.project.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.dao.RequestDAO;
import com.project.dto.RequestVO;

@WebServlet("/requestIn.do")
public class RequestInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RequestInServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher ds = request.getRequestDispatcher("member/RequestIn.jsp");
		ds.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 한글이 깨지지않게 인코딩 설정
		request.setCharacterEncoding("UTF-8");
		
		
		
		// 폼에서 입력한 회원 정보를 얻어옴
		String name = request.getParameter("name");
		String userid = request.getParameter("userid");
		String title = request.getParameter("title");
		String language = request.getParameter("language");
		String content = request.getParameter("content");
		
		
		
		//의뢰내용을 저장할 객체를 생성
		RequestVO rvo = new RequestVO();
		rvo.setName(name);
		rvo.setUserid(userid);
		rvo.setTitle(title);
		rvo.setLanguage(language);
		rvo.setContent(content);
		
		
		
		RequestDAO rdao = RequestDAO.getins();
		int re = rdao.insertRequest(rvo);
		
		HttpSession se = request.getSession();
		
		if(re==1) {
			se.setAttribute(userid, rvo.getTitle());
			request.setAttribute("requestressage", "의뢰가 등록 되었습니다");
		}else {
			request.setAttribute("requestressage", "의뢰가 등록 되지 않았습니다");
		}
		
		 RequestDispatcher dis = request.getRequestDispatcher("member/RequestIn.jsp");
		    dis.forward(request, response);

	}

}
