package com.project.dto;

import java.sql.Timestamp;

public class ReVO {
	
	private int num;
	private String pass; //
	private String name; //
	private String userid; //
	private String eamli; //
	private String title;  //
	private String language; //
	private String content; //
	private String flie; //
	private String closedate; //
	private String cash; //
	private int readcont;
	private Timestamp wrirdate;
	
	
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	
	
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	
	
	public String getEamli() {
		return eamli;
	}
	public void setEamli(String eamli) {
		this.eamli = eamli;
	}
	
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	
	
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	
	
	public String getFlie() {
		return flie;
	}
	public void setFlie(String flie) {
		this.flie = flie;
	}
	
	
	
	public String getClosedate() {
		return closedate;
	}
	public void setClosedate(String closedate) {
		this.closedate = closedate;
	}
	
	
	
	public String getCash() {
		return cash;
	}
	public void setCash(String cash) {
		this.cash = cash;
	}
	
	
	
	public int getReadcont() {
		return readcont;
	}
	public void setReadcont(int readcont) {
		this.readcont = readcont;
	}
	
	
	
	public Timestamp getWrirdate() {
		return wrirdate;
	}
	public void setWrirdate(Timestamp wrirdate) {
		this.wrirdate = wrirdate;
	}
	
	
	
	

}
