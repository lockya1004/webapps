package com.project.dto;

public class RequestVO {
	
	private String name;
	private String userid;
	private String title;
	private String language;
	private String content;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	
	
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	
	
	
	
	@Override
	public String toString() {
		return "RequestVO [name=" + name + ", userid=" + userid + ", title=" + title + ", language=" + language
				+ ", content=" + content + "]";
	}
	
	

}
