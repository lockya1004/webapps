package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.project.dto.RequestVO;
import com.project.util.DBManager;

public class RequestDAO {

	private RequestDAO() {

	}

	private static RequestDAO ins = new RequestDAO();

	public static RequestDAO getins() {
		return ins;
	}
	
	
	
	public RequestVO getRequest(String userid) {
		RequestVO rvo = null;
		String sql = "select * from request where userid=?";
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBManager.getConnection();
			ps = con.prepareStatement(sql);
			ps.setString(1, userid);
			if(rs.next()) {
				rvo = new RequestVO();
				rvo.setName(rs.getString("name"));
				rvo.setUserid(rs.getString("userid"));
				rvo.setTitle(rs.getString("title"));
				rvo.setLanguage(rs.getString("language"));
				rvo.setContent(rs.getString("content"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			of(con,ps,rs);
		}
		return rvo;
	}
	
	
	
	
	public int insertRequest(RequestVO rvo) {
		int re = -1;
		String sql = "insert into request values(?, ?, ?, ?, ?)";
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DBManager.getConnection();
			ps = con.prepareStatement(sql);
			ps.setString(1, rvo.getName());
			ps.setString(2, rvo.getUserid());
			ps.setString(3, rvo.getTitle());
			ps.setString(4, rvo.getLanguage());
			ps.setString(5, rvo.getContent());
			re = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			of(con, ps, null);
		}
		return re;
	}
	
	
	
	
	
	public int updateRequest(RequestVO rvo) {
		
		int re = -1;
		String sql = "update request set title=?, language=?, content=? where userid=?";
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DBManager.getConnection();
			ps = con.prepareStatement(sql);
			ps.setString(1, rvo.getTitle());
			ps.setString(2, rvo.getLanguage());
			ps.setString(3, rvo.getContent());
			ps.setString(4, rvo.getUserid());
			re = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			of(con, ps, null);
		}
		return re;
	}

	
	
	
	
	
	///// close 해주는 메소드
	private void of(Connection con, PreparedStatement ps, ResultSet rs) {

		try {
			if (con != null)
				con.close();
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
