package com.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.project.dto.ReVO;
import com.project.util.ReDBManager;

public class ReDAO {

	private ReDAO() {
		
	}

	private static ReDAO ins = new ReDAO();
	
	public static ReDAO getins() {
		return ins;
	}
		
	
	public List<ReVO> selectAllRe(){
		
	   String sql = "select from re order by num desc";
	   
	   List<ReVO> list = new ArrayList<ReVO>();
	   Connection conn = null;
	   Statement stmt = null;
	   ResultSet rs = null;
	   
	   try {
		conn = ReDBManager.getConnection();
		stmt = conn.createStatement();
		rs = stmt.executeQuery(sql);
		
		while(rs.next()) {
			
			ReVO revo = new ReVO();
			revo.setNum(rs.getInt("num"));
			revo.setPass(rs.getString("pass"));
			revo.setName(rs.getString("name"));
			revo.setUserid(rs.getString("userid"));
			revo.setEamli(rs.getString("eamli"));
			revo.setTitle(rs.getString("title"));
			revo.setLanguage(rs.getString("language"));
			revo.setContent(rs.getString("content"));
			revo.setFlie(rs.getString("flie"));
			revo.setClosedate(rs.getString("closedate"));
			revo.setCash(rs.getString("cash"));
			revo.setReadcont(rs.getInt("readcont"));
			revo.setWrirdate(rs.getTimestamp("wrirdate"));
			
			list.add(revo);
			
		}
	} catch (Exception e) {
		e.printStackTrace();
	}finally {
		ReDBManager.close(conn, stmt, rs);
	}
	   return list;
	}
	
	public void insertRe(ReVO rvo) {
		String sql = "insert into re("
				+ "num, pass, name, userid, eamli, title, language, content, flie, closedate, cash)"
				+ "values(re_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = ReDBManager.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, rvo.getPass());
			pstmt.setString(2, rvo.getName());
			pstmt.setString(3, rvo.getUserid());
			pstmt.setString(4, rvo.getEamli());
			pstmt.setString(5, rvo.getTitle());
			pstmt.setString(6, rvo.getLanguage());
			pstmt.setString(7, rvo.getContent());
			pstmt.setString(8, rvo.getFlie());
			pstmt.setString(9, rvo.getClosedate());
			pstmt.setString(10, rvo.getCash());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			ReDBManager.close(conn, pstmt);
		}
	}
	
	public void updateReadCont(String num) {
		String sql = "update re set readcont=readcont+1 where num=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = ReDBManager.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, num);
			
			pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			ReDBManager.close(conn, pstmt);
		}
	}
	
	//게시판 글 상세 내용 보기 :글번호로 찾아온다.
}

















