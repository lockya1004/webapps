function requestCheck(){
	if(document.frm.title.value.length == 0){
		alert("제목을 써주세요");
		frm.title.focus();
		return false;
	}
	
	if(document.frm.language.value.length == 0){
		alert("언어등록을 입력 해주세요");
		frm.language.focus();
		return false;
	}
	
	if(document.frm.content.value.length == 0){
		alert("의뢰등록을 해주세요");
		frm.content.focus();
		return false;
	}
	return true;
}