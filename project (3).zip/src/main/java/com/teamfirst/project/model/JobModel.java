package com.teamfirst.project.model;

import java.sql.Timestamp;

public class JobModel {
	private int jobNum;
	private Timestamp jobRegDate;
	private String jobContent;
	private String agentName;
	private String jobType;

	public int getJobNum() {
		return jobNum;
	}

	public void setJobNum(int jobNum) {
		this.jobNum = jobNum;
	}

	public Timestamp getJobRegDate() {
		return jobRegDate;
	}

	public void setJobRegDate(Timestamp jobRegDate) {
		this.jobRegDate = jobRegDate;
	}

	public String getJobContent() {
		return jobContent;
	}

	public void setJobContent(String jobContent) {
		this.jobContent = jobContent;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
}
