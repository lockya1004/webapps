package com.teamfirst.project.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamfirst.project.dao.SupportDAO;
import com.teamfirst.project.model.SupportModel;

@Repository("supportDAO")
public class SupportDAOImpl implements SupportDAO {

	@Inject
	private SqlSession sqlSession;

//	private static final String NAMESPACE = "com.teamfirst.project.dao.SupportDAO";

	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public int regSupport(SupportModel model) {		
		return sqlSession.insert("insertSupport", model);
	}

	@Override
	public List<SupportModel> getSupportList() {
		if(sqlSession == null){
			System.out.println("���� �� ����");
		}else{
			System.out.println("���� �� ����");
		}
		return sqlSession.selectList("selectSupport");
	}

	@Override
	public int updateSupport(SupportModel model) {
		return sqlSession.update("updateSupport", model);
	}

	@Override
	public int delSupport(int num) {
		return sqlSession.delete("delSupport", num);
	}

	@Override
	public List<SupportModel> searchSupport(String keyword) {
		return sqlSession.selectList("searchSupport", keyword);
	}

	@Override
	public SupportModel getSelectByNum(int num) {
		return sqlSession.selectOne("selectSupportByNum", num);
	}

	@Override
	public List<SupportModel> getMenuList(String kinds) {
		return sqlSession.selectList("selectMenuList", kinds);
	}    	
}
