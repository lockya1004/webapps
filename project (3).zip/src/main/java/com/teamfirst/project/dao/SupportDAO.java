package com.teamfirst.project.dao;

import java.util.List;
import com.teamfirst.project.model.SupportModel;

public interface SupportDAO {
	   
		int regSupport(SupportModel model);
		List<SupportModel> getSupportList();
		int updateSupport(SupportModel model);
		int delSupport(int num);
		List<SupportModel> searchSupport(String keyword);
		SupportModel getSelectByNum(int num);
		List<SupportModel> getMenuList(String kinds);
}
