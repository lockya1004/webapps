package com.teamfirst.project.dao;

import java.util.List;

import com.teamfirst.project.model.ClientModel;

public interface ClientDAO  {
	int regClient(ClientModel model);
	List<ClientModel> listClient();
	List<ClientModel> selectClient(int num);
	int updateClient(ClientModel client);
	int deleteClient(int num);
	List<ClientModel> searchClient(String keyword);
	
}
