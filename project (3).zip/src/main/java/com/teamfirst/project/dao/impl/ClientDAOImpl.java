package com.teamfirst.project.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamfirst.project.dao.ClientDAO;
import com.teamfirst.project.model.ClientModel;

@Repository("clientDAO")
public class ClientDAOImpl implements ClientDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }
     
	@Override
	public int regClient(ClientModel model) {		
		return sqlSession.insert("insertClient", model);
	}

	@Override
	public List<ClientModel> listClient() {
		
		return sqlSession.selectList("listClient");
	}

	@Override
	public List<ClientModel> selectClient(int num) {
		
		return sqlSession.selectOne("selectClient",num);
	}

	@Override
	public int updateClient(ClientModel client) {
	
		return sqlSession.update("updateClient",client);
	}

	@Override
	public int deleteClient(int num) {
		return sqlSession.delete("delectClient",num);
	}

	@Override
	public List<ClientModel> searchClient(String keyword) {
		return sqlSession.selectList("searchClient",keyword);
	}		
}
