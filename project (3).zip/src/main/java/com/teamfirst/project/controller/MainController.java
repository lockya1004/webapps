package com.teamfirst.project.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.w3c.dom.Document;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.teamfirst.project.model.MainModel;
import com.teamfirst.project.model.WeatherModel;
import com.teamfirst.project.service.MainService;
import com.teamfirst.project.service.WeatherService;

@Controller
public class MainController {

   @Inject
   private MainService mainService;
   @Inject
   private WeatherService weatherService;

   @RequestMapping("/")
   public String main(Model model) throws SQLException {
      List<MainModel> listMainModel = mainService.getNewList();

      model.addAttribute("main", listMainModel);
      model.addAttribute("main", getLang(listMainModel));

      List<WeatherModel> list = weatherService.getWeather();
      if (list.isEmpty()) {
         getWeatherFromRemote();
      } //else    
         model.addAttribute("weatherlist", weatherService.getWeather());
      return "main";
   }
   
   int i=0;

   @RequestMapping(value = "/weather")
   public String weatherDate(Model model) throws Exception {
      Calendar cal = Calendar.getInstance();
      Date nowdate = cal.getTime();
      long now = nowdate.getTime();
      
      List<WeatherModel> list = weatherService.getWeather();
      Date dbdate = list.get(0).getDay();
      long dbtime = dbdate.getTime();
      
      System.out.println("하아아아아아아~~!!!!" + (now - dbtime) / 1000 / 3600);

      if(i>20){
    	  i=0;
      }else{ 
    	 System.out.println(i); 
    	 i++;
      }
      
      
      if (Math.round((now - dbtime) / 1000 / 3600) >= 1) {
         weatherService.delWeather();
        getWeatherFromRemote();
   
      }
      return "main";
   }

   @RequestMapping(method = RequestMethod.GET, value = "header")
   public String header(Model model) {
      return "include/header";
   }

   @RequestMapping(method = RequestMethod.GET, value = "footer")
   public String footer(Model model) {
      return "include/footer";
   }

   public List<MainModel> getLang(List<MainModel> mainModel) {
      String srcLanguage = "";
      String targlanguage = "";

      try {

         // xml file location
         String fileurl = this.getClass().getResource("").getPath();
         String path = fileurl.substring(1, fileurl.indexOf("project")) + "project/resources/xml/languages.xml";
         Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(path));
         doc.getDocumentElement().normalize();
         XPath xPath = XPathFactory.newInstance().newXPath();

         for (int j = 0; j < mainModel.size(); j++) {
            String expSourceLang = "/languages/language[value=" + mainModel.get(j).getSourceLang() + "]";
            String expTargetLang = "/languages/language[value=" + mainModel.get(j).getTargetLang() + "]";

            Node nodeSourceLang = (Node) xPath.compile(expSourceLang).evaluate(doc, XPathConstants.NODE);
            NodeList nodeSourceLangList = (NodeList) xPath.compile(expSourceLang).evaluate(doc,
                  XPathConstants.NODESET);

            Node nodeTargetLang = (Node) xPath.compile(expTargetLang).evaluate(doc, XPathConstants.NODE);
            NodeList nodeTargetLangList = (NodeList) xPath.compile(expTargetLang).evaluate(doc,
                  XPathConstants.NODESET);

            // if (null != nodeSourceLang||null != nodeTargetLang)
            {
               nodeSourceLangList = nodeSourceLang.getChildNodes();
               nodeTargetLangList = nodeTargetLang.getChildNodes();

               for (int i = 0; i < nodeSourceLangList.getLength(); i++) { // null
                                                            // !=
                                                            // nodeSourceLangList
                                                            // &&
                  Node nodeSource = nodeSourceLangList.item(i);
                  Node nodeTarget = nodeTargetLangList.item(i);
                  if (nodeSource.getNodeType() == Node.ELEMENT_NODE) {
                     srcLanguage = nodeSource.getFirstChild().getNodeValue(); //
                  }
                  if (nodeTarget.getNodeType() == Node.ELEMENT_NODE) {
                     targlanguage = nodeTarget.getFirstChild().getNodeValue(); //
                  }
               }
            }
            mainModel.get(j).setSource(srcLanguage);
            mainModel.get(j).setTarget(targlanguage);
         }

      } catch (Exception e) {
         e.printStackTrace();
      }

      return mainModel;
   }

   public void getWeatherFromRemote() {
      try {
         String apiId = "c08918b19d0762a7c8ef9e3c49c16174";
         String location = "1835848,1838524,1835329,1843564,1841811,1835235,1833747,1846266";
         String urlstr = "http://api.openweathermap.org/data/2.5/group?id=" + location + "&units=metric&APPID="
               + apiId;
         URL url = new URL(urlstr);
         BufferedReader bf;
         String line;
         String result = "";
         WeatherModel wr = new WeatherModel();

         // 날씨 정보를 받아온다.
         bf = new BufferedReader(new InputStreamReader(url.openStream()));

         // 버퍼에 있는 정보를 문자열로 변환.
         while ((line = bf.readLine()) != null) {
            result = result.concat(line);
            // System.out.println(line);
         }
         System.out.println(result);
         // 문자열을 JSON으로 파싱
         JSONParser jsonParser = new JSONParser();
         JSONObject jsonObj = (JSONObject) jsonParser.parse(result);

         // 날씨 출력
         JSONArray listArray = (JSONArray) jsonObj.get("list");
         for (int i = 0; i < listArray.size(); i++) {
            JSONObject obj = (JSONObject) listArray.get(i);
            System.out.println("obj : " + obj);
            // 지역 출력

            System.out.println(obj.get("name").toString());
            wr.setLocation(obj.get("name").toString());
            JSONArray weatherarr = (JSONArray) obj.get("weather");
            JSONObject weatherobj = (JSONObject) weatherarr.get(0);
            System.out.println("날씨 : " + weatherobj.get("icon"));
            wr.setIcon(weatherobj.get("icon").toString());
            // 온도 출력(절대온도라서 변환 필요)
            JSONObject mainArray = (JSONObject) obj.get("main");
            double ktemp = Double.parseDouble(mainArray.get("temp").toString());
            wr.setTemp(Math.round(ktemp));
            System.out.printf("온도 :" + wr.getTemp());
            weatherService.regWeather(wr);
         }
         bf.close();
      } catch (Exception e) {
         e.printStackTrace();
      }

   }

}