package com.teamfirst.project.controller;

import java.sql.SQLException;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.teamfirst.project.model.ClientModel;
import com.teamfirst.project.service.ClientService;

@Controller
public class ClientController {

	@Inject
	private ClientService clientService;
	
	@RequestMapping("/client/go.register")
	public String clientRegister(Model model) throws SQLException {
		
		return "client/clientRegister";
	}
	
	@RequestMapping("/client/go.insert")
	public String clientInsert(ClientModel clientmodel) throws SQLException {
		clientService.regClient(clientmodel);
		return "redirect:/client/go.list";
	}
	
	
	@RequestMapping("/client/go.list")
	public String listClient(Model model) throws SQLException{

		List<ClientModel> list=clientService.listClient();
		model.addAttribute("clientlist", list);
		
		return "client/clientSearch";
	}
	
	
	@RequestMapping("/client/go.search")
	public String reqList(Model model, HttpServletRequest request,String keyword) throws SQLException {
		keyword=request.getParameter("keyword");
		System.out.println(keyword);
	
		List<ClientModel> searchlist=clientService.searchClient(keyword);
		model.addAttribute("clientlist",searchlist);
			return "client/clientSearch";
	}
	
	
	
}
