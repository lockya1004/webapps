package com.teamfirst.project.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.teamfirst.project.model.LinguistModel;
import com.teamfirst.project.service.LinguistService;

@Controller
public class LinguistController {
	
	@Inject
	private LinguistService linguistProfileService;
	
	@Resource(name="uploadPath")
	private String uploadPath;
	
	
	@RequestMapping("/linguist/go.register")
	public String linguistRegister(Model model) throws SQLException {
		
		return "linguist/linguistRegister";
	}
	

	@RequestMapping(value="/linguist/go.insert", method=RequestMethod.POST)
	public String linguistInsert(HttpServletRequest request, MultipartFile file, Model model, @ModelAttribute("linguistmodel") LinguistModel linguistmodel) throws Exception {
		MultipartHttpServletRequest multi=(MultipartHttpServletRequest)request;
		Iterator<String> iterator=multi.getFileNames();
		file=multi.getFile(iterator.next());
		if(file.isEmpty()==false){
			System.out.println(file.getName());
			System.out.println("bbbbbbbbbb : "+file.getOriginalFilename());
		}
		
		String savedName=uploadFile(file.getOriginalFilename(),file.getBytes());
		System.out.println("aaaaaaaaaaaa"+savedName);
		
		linguistProfileService.regLinguist(linguistmodel);
		
		model.addAttribute("savedName",savedName);
		
		
		return "redirect:/linguist/go.search";
	}
	
	private String uploadFile(String originalFilename,byte[] fileData) throws Exception{
		
		UUID uid=UUID.randomUUID();
		String savedName=uid.toString()+"_"+originalFilename;
		File target=new File(uploadPath, savedName);
		
		FileCopyUtils.copy(fileData, target);
		return savedName;
	}
	
	
	@RequestMapping("/linguist/go.search")
	public String linguistSearch(Model model) throws SQLException {
		List<LinguistModel> list=linguistProfileService.getLinguistList();
		model.addAttribute("linguistlist",list);
		return "linguist/linguistSearch";
	}
}
