package com.teamfirst.project.controller;

import java.sql.SQLException;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.teamfirst.project.model.MemberModel;
import com.teamfirst.project.service.MemberService;

@Controller
public class MemberController {

   @Inject
   private MemberService memberService;
   
   @RequestMapping("/join")
   public String memberJoinForm( ){
      return "member/memberJoin";    
   }
   
   @RequestMapping(value="/join/go.join", method=RequestMethod.POST)
   public String memberJoin(MemberModel model) throws SQLException{
//      model.addAttribute("main", memberService.getNewList());
//      response.sendRedirect("member/memberJoin");
      memberService.regMember(model);
      return "redirect:/";

   }
   
   @RequestMapping("/idcheck")
public String idcheck(HttpServletRequest request) throws SQLException{
	   String id=request.getParameter("userid");
	   int re=memberService.conrfirmMember(id);
	   request.setAttribute("userid", id);
	   request.setAttribute("result",re);
	   
	  
	   return "member/idcheck";
   }   
   
}