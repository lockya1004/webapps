package com.teamfirst.project.controller;

import java.sql.SQLException;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.teamfirst.project.service.SupportService;

@Controller
public class SupportController {

	@Inject
	private SupportService supportService;
	
	@RequestMapping("support/go.list")
	public String supportList(Model model) throws SQLException{
		if(model == null){
			System.out.println("model null");
		}
		
		//supportService ����
		if(supportService == null){
			System.out.println("supportService null");
		}
		
		model.addAttribute("supportList", supportService.getSupportList());
		return "support/supportList";    
	}
	
	@RequestMapping("support/go.view")
	public String supportView(Model model) throws SQLException{
		if(model == null){
			System.out.println("�� �� ����");
		}
		
		//supportService ����
		if(supportService == null){
			System.out.println("���� �ȵ�");
		}
		
		model.addAttribute("supportList", supportService.getSupportList());
		return "support/supportView";    
	}
	
	@RequestMapping("support/go.write")
	public String supportWrite(Model model) throws SQLException{

		return "support/supportWrite";    
	}
}
