package com.teamfirst.project.controller;

import java.io.File;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;


import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.teamfirst.project.model.LinguistModel;
import com.teamfirst.project.service.LinguistService;

@Controller
public class LinguistController {
	
	@Inject
	private LinguistService linguistProfileService;

	@RequestMapping("linguist/go.register")
	public String linguistRegister(HttpSession session,Model model) throws SQLException {
		if(session.getAttribute("userid")==null){
			return "member/login";
		}else{
		
			return "linguist/linguistRegister";
		}
	
	}
	

	@RequestMapping(value="linguist/go.insert", method=RequestMethod.POST)
	public String linguistInsert(HttpServletRequest request, LinguistModel linguistmodel) throws Exception {
		fileUpload(linguistmodel,request);
		
		return "redirect:/linguist/go.search";
	}

	
	@RequestMapping("linguist/go.search")
	public String linguistSearch(Model model) throws SQLException {
		List<LinguistModel> list=linguistProfileService.getLinguistList();
		model.addAttribute("linguistlist",list);
		return "linguist/linguistSearch";
	}
	
	public void fileUpload(LinguistModel model,HttpServletRequest request){
		HttpSession session=request.getSession();
		
	
		try{
			MultipartHttpServletRequest multi=(MultipartHttpServletRequest)request;
			Iterator<String> iterator=multi.getFileNames();
			MultipartFile file=null;
			while(iterator.hasNext()){
				file=multi.getFile(iterator.next());
				if(file.isEmpty()==false){
					System.out.println("file : "+file.getName());
					System.out.println("filename : "+file.getOriginalFilename());
					String path=session.getServletContext().getRealPath("/");
					String uuid = UUID.randomUUID().toString();
					String relpath=path+"resources/files/"+file.getOriginalFilename();
					File serverFile=new File(relpath+uuid);
					file.transferTo(serverFile);

              	model.setTrans_picurl(file.getOriginalFilename());
				linguistProfileService.regLinguist(model);
                  
                      }
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
