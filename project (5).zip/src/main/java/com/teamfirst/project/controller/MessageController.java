package com.teamfirst.project.controller;

import java.sql.SQLException;
import java.util.List;


import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.teamfirst.project.model.MessageModel;
import com.teamfirst.project.service.MessageService;

@Controller
public class MessageController {
//메세지 폼
	
	@Inject
	private MessageService messageService;
		
	@RequestMapping(value="message/go.form")
	public String messageForm(@RequestParam("id") String id,HttpServletRequest request){
		request.setAttribute("toid", id);
	return "message/messageForm";	
	}
//메세지 보내기
	
	@RequestMapping(value="message/go.send", method=RequestMethod.POST)
	public String sendMessage(@SessionAttribute("userid") String userid,MessageModel message,HttpServletRequest request) throws SQLException{
		
		message.setFromid(userid);
		message.setToid(request.getParameter("toid"));
		message.setContent(request.getParameter("content"));
		System.out.println("message : "+message.getContent());
		messageService.regMessage(message);
		return "redirect:/message/go.to";
	} 
	
//받은 메세지 보기
	@RequestMapping(value="message/go.view")
	public String viewMessage(Model model,@RequestParam("num") String num) throws SQLException{
		int number=Integer.parseInt(num);
		MessageModel message=messageService.getReadMessage(number);
		messageService.updateReadMessage(number);
		model.addAttribute("list_to",message);
		return "message/messageForm";
	}
	
	
	//휴지통
	@RequestMapping(value="message/mslstrash")
	public String listTrash(Model model) throws SQLException{
		List<MessageModel> list=messageService.getTrashedMessage();
		model.addAttribute("list_waste", list);
		return "message/messageList_waste";
	}
	
	
//보관함
	@RequestMapping(value="message/mslskeep")
	public String listKeep(Model model) throws SQLException{
		List<MessageModel> list=messageService.getKeptMessageList();
		model.addAttribute("list_keep", list);
		return "message/messageList_keep";
	}

//보낸쪽지함
	@RequestMapping(value="message/mslsfrom")
	public String listFrom(Model model,@SessionAttribute("userid") String userid) throws SQLException{
		List<MessageModel> list=messageService.getSentMessage(userid);
		model.addAttribute("list_from", list);
		return "message/messageList_from";
	}
	
//받은 쪽지함
	@RequestMapping(value="message/go.to")
	public String listTo(Model model,@SessionAttribute("userid") String userid) throws SQLException{
		List<MessageModel> list=messageService.getMyMessage(userid);
		model.addAttribute("list_to", list);
		return "message/messageList_to";
	}
	
 //영구삭제, 삭제, 보관버튼
	@RequestMapping(value="message/btmu")
	public String button(@RequestParam("btnid") String btnid, @RequestParam("num") String num) throws SQLException{
		String[] numlist;	
		if(btnid.equals("waste")) {
			numlist	= num.split(",");
			System.out.println(btnid);
			
			for(int i=0; i<numlist.length; i++) {
				System.out.println("tmp : "+numlist[i]);
				messageService.updateTrashMessage(Integer.parseInt(numlist[i]));
				}
				return "redirect:/message/go.to";
			}else if(btnid.equals("keep")){
				numlist = num.split(",");

				for(int i=0; i<numlist.length; i++) {
					System.out.println("tmp : "+numlist[i]);
					messageService.updateRecoveryMessage(Integer.parseInt(numlist[i]));
					}	
				return "redirect:/message/go.to";
			}else if(btnid.equals("delete")) {
				numlist = num.split(",");

				for(int i=0; i<numlist.length; i++) {
					System.out.println("tmp : "+numlist[i]);
					messageService.deleteMessage(Integer.parseInt(numlist[i]));
					}
				return "message/messageList_waste";
				
			}else if(btnid.equals("alldel")){
				messageService.deleteAllMessages();
				return "message/messageList_waste";
			}
		return null;
		
	}

	
}
