package com.teamfirst.project.interceptor;
import javax.inject.Inject;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.util.WebUtils;

import com.teamfirst.project.model.MemberModel;
import com.teamfirst.project.service.MemberService;

public class AuthInterceptor extends HandlerInterceptorAdapter {
  private static final Logger logger = LoggerFactory.getLogger(AuthInterceptor.class);
  
  @Inject
  private MemberService memberService;
  
  @Override
  public boolean preHandle(HttpServletRequest request,
      HttpServletResponse response, Object handler) throws Exception {
    
    HttpSession session = request.getSession();   
   System.out.println("session: "+session);
    if(session.getAttribute("login") == null){   
      logger.info("current user is not logined");     
      saveDest(request);
      
  /*    Cookie loginCookie = WebUtils.getCookie(request, "loginCookie");
      
      if(loginCookie != null) { 
        
        MemberModel memberModel = memberService.checkLoginBefore(loginCookie.getValue());
        
        logger.info("MemberModel: " + memberModel);
        
        if(memberModel != null){
          session.setAttribute("login", memberModel);
          return true;
        }        
      }*/

      response.sendRedirect("/teamf/login");
      return false;
    }
    return true;
  }  
  

  private void saveDest(HttpServletRequest req) {

    String uri = req.getRequestURI();
    String query = req.getQueryString();

    if (query == null || query.equals("null")) {
      query = "";
    } else {
      query = "?" + query;
    }

    if (req.getMethod().equals("GET")) {
      logger.info("dest: " + (uri + query));
      req.getSession().setAttribute("dest", uri + query);
    }
  }
}


