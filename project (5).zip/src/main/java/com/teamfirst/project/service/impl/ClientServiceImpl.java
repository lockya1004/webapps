package com.teamfirst.project.service.impl;

import java.sql.SQLException;
import java.util.List;

import javax.inject.Inject;
import org.springframework.stereotype.Service;

import com.teamfirst.project.dao.ClientDAO;
import com.teamfirst.project.model.ClientModel;
import com.teamfirst.project.service.ClientService;

@Service("clientService")
public class ClientServiceImpl implements ClientService{

	@Inject
	private ClientDAO clientDAO;
	
	@Override
	public int regClient(ClientModel model) {		
		return clientDAO.regClient(model);
	}

	@Override
	public List<ClientModel> listClient() throws SQLException {
	
		return clientDAO.listClient();
	}

	@Override
	public ClientModel selectClient(int num) throws SQLException {
	
		return clientDAO.selectClient(num);
	}

	@Override
	public int updateClient(ClientModel client) throws SQLException {
		return clientDAO.updateClient(client);
	}

	@Override
	public int deleteClient(int num) throws SQLException {
		return clientDAO.deleteClient(num);
	}

	@Override
	public List<ClientModel> searchClient(String keyword) throws SQLException {
		
		return clientDAO.searchClient(keyword);
	}

	
	

}
