package com.teamfirst.project.service.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.teamfirst.project.dao.MainDAO;
import com.teamfirst.project.model.MainModel;
import com.teamfirst.project.service.MainService;

@Service("mainService")
public class MainServiceImpl implements MainService {

	@Inject
	private MainDAO mainDAO;

	@Override
	public List<MainModel> getNewList() {
		if(mainDAO == null){
			System.out.println("mainDAO null.");
		}
		return mainDAO.getNewList();
	}

}
