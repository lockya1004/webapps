package com.teamfirst.project.service.impl;

import java.util.List;


import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.teamfirst.project.dao.WeatherDAO;
import com.teamfirst.project.model.WeatherModel;
import com.teamfirst.project.service.WeatherService;

@Service("weatherService")
public class WeatherServiceImpl implements WeatherService{

	@Inject
	private WeatherDAO weatherDAO;

	@Override
	public int regWeather(WeatherModel model) {
		return weatherDAO.regWeather(model);
	}

	@Override
	public int delWeather() {
		return weatherDAO.delWeather();
	} 

	@Override
	public List<WeatherModel> getWeather() {
		return weatherDAO.getWeather();
	}	
}