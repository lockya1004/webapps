package com.teamfirst.project.dao;

import java.util.List;
import com.teamfirst.project.model.JobModel;
import com.teamfirst.project.model.LinguistModel;

public interface LinguistDAO {
	int regLinguist(LinguistModel model);
	List<LinguistModel> getLinguistList();
	LinguistModel getLinguistListByNum(int num);
	LinguistModel getLinguistListById(String id);
	LinguistModel getLinguistListByCode(int code);
	int updateLinguist(LinguistModel model);
	List<JobModel> getJobList();
	List<LinguistModel> searchLinguist(String keyword);
}
