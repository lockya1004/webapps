package com.teamfirst.project.model;

public class LinguistModel {
	private int trans_num;
	private String trans_picurl;
	private String trans_src_language;
	private String trans_area;
	private String trans_portfolio;
	private String trans_name;
	private String trans_address;
	private String trans_id;
	private String trans_payRate;
	private String tans_contact;
	private String trans_software;
	private String trans_targ_language;
	
	public int getTrans_num() {
		return trans_num;
	}
	public void setTrans_num(int trans_num) {
		this.trans_num = trans_num;
	}
	public String getTrans_picurl() {
		return trans_picurl;
	}
	public void setTrans_picurl(String trans_picurl) {
		this.trans_picurl = trans_picurl;
	}
	public String getTrans_src_language() {
		return trans_src_language;
	}
	public void setTrans_src_language(String trans_src_language) {
		this.trans_src_language = trans_src_language;
	}
	public String getTrans_area() {
		return trans_area;
	}
	public void setTrans_area(String trans_area) {
		this.trans_area = trans_area;
	}
	public String getTrans_portfolio() {
		return trans_portfolio;
	}
	public void setTrans_portfolio(String trans_portfolio) {
		this.trans_portfolio = trans_portfolio;
	}
	public String getTrans_targ_language() {
		return trans_targ_language;
	}
	public void setTrans_targ_language(String trans_targ_language) {
		this.trans_targ_language = trans_targ_language;
	}
	public String getTrans_name() {
		return trans_name;
	}
	public void setTrans_name(String trans_name) {
		this.trans_name = trans_name;
	}
	public String getTrans_address() {
		return trans_address;
	}
	public void setTrans_address(String trans_address) {
		this.trans_address = trans_address;
	}
	public String getTrans_id() {
		return trans_id;
	}
	public void setTrans_id(String trans_id) {
		this.trans_id = trans_id;
	}
	public String getTrans_payRate() {
		return trans_payRate;
	}
	public void setTrans_payRate(String trans_payRate) {
		this.trans_payRate = trans_payRate;
	}
	public String getTans_contact() {
		return tans_contact;
	}
	public void setTans_contact(String tans_contact) {
		this.tans_contact = tans_contact;
	}
	public String getTrans_software() {
		return trans_software;
	}
	public void setTrans_software(String trans_software) {
		this.trans_software = trans_software;
	}

	
	
}