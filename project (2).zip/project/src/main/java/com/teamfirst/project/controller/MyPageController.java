package com.teamfirst.project.controller;

import java.sql.SQLException;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.teamfirst.project.service.MyPageService;


@Controller
public class MyPageController {
	
	@Inject
	private MyPageService myPageService;

	@RequestMapping("/go.mypage")
	public String myPage(Model model) throws SQLException{
		
/*		HttpSession httpSession =login;
//		sendRedirect(userid != null ? (String) dest : "/");			
		model.addAttribute("userid", userid);*/
		return "/myPage/myPageView";
	}
	
	

}
