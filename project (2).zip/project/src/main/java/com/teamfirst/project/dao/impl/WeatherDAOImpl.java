package com.teamfirst.project.dao.impl;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamfirst.project.dao.WeatherDAO;
import com.teamfirst.project.model.WeatherModel;

@Repository("weatherDAO")
public class WeatherDAOImpl implements WeatherDAO {

	@Inject
	private SqlSession sqlSession;
	
//	private static final String NAMESPACE = "com.teamfirst.project.dao.WeatherDAO";
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public int regWeather(WeatherModel model) {
		return sqlSession.insert("insertWeather", model);
	}

	@Override
	public int delWeather() {
		return sqlSession.delete("delWeather");
	}

	@Override
	public List<WeatherModel> getWeather() {
			List<WeatherModel> listWeather = sqlSession.selectList("selectWeather");
		
		return listWeather;
	}    			
	
}
