package com.teamfirst.project.service.impl;

import java.util.List;
import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.teamfirst.project.dao.MyPageDAO;
import com.teamfirst.project.model.MyPageModel;
import com.teamfirst.project.service.MyPageService;

@Service("myPageService")
public class MyPageServiceImpl implements MyPageService{

	@Inject
	private MyPageDAO myPageDAO;

	@Override
	public MyPageModel getMyProfile(String id) {
		return myPageDAO.getMyProfile(id);
	}

	@Override
	public List<MyPageModel> getReplyList(String id) {
		return myPageDAO.getReplyList(id);
	}	
}
