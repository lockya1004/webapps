package com.teamfirst.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;




//@Repository
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
		locations = {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"}
		)
public class DaoTest {

	@Autowired //@Inject
	private DataSource ds;
	
	@Test
	public void getTest() throws SQLException{
		
		Connection con = ds.getConnection();
		PreparedStatement pstm = con.prepareStatement("SELECT * FROM project.member");
		
		ResultSet rs = pstm.executeQuery();
		rs.next();
		System.out.println("rs.getString(2): "+rs.getString(2));
		
//		return rs.getString(1);
		
	}
}
