package com.teamfirst.project.dao.impl;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamfirst.project.dao.RequestDAO;
import com.teamfirst.project.model.RequestModel;

@Repository("requestDAO")
public class RequestDAOImpl implements RequestDAO {

	@Inject
	private SqlSession sqlSession;
	private static final String NAMESPACE = "com.teamfirst.project.RequestMapper";
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }

	@Override
	public List<RequestModel> getAllRequest() {		
		return sqlSession.selectList(NAMESPACE+".selectAllRequest");
	}

	@Override
	public int regRequest(RequestModel model) {		
		return sqlSession.insert(NAMESPACE+".insertRequest", model);
	}

	@Override
	public int updateReadCount(String num) {
//		System.out.println("updateReadCount start");
		return sqlSession.update(NAMESPACE+".updateReadCount", num);
	}

	@Override
	public RequestModel getRequestDetailsByNum(String num) {
		return sqlSession.selectOne(NAMESPACE+".selectRequestDetailsByNum", num);
	}

	@Override
	public int updateRequest(RequestModel model) {
		return sqlSession.update(NAMESPACE+".updateRequest", model);
	}

	@Override
	public RequestModel checkPassWord(String pass, String num) {
		HashMap<String, String> map = new HashMap<>();
		map.put("pass", pass);
		map.put("num", num);
		return	sqlSession.selectOne(NAMESPACE+".checkPassWord", map);		
	}

	@Override
	public int delRequest(String num) {
		return sqlSession.delete("deleteRequest", num);
	}

	@Override
	public List<RequestModel> getRequestList() {
		return sqlSession.selectList("selectRequestList");
	}	
}
