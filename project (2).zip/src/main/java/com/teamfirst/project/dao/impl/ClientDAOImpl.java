package com.teamfirst.project.dao.impl;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.teamfirst.project.dao.ClientDAO;
import com.teamfirst.project.model.ClientModel;

@Repository("clientDAO")
public class ClientDAOImpl implements ClientDAO {

	@Inject
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
        this.sqlSession = sqlSession;
    }
     
	@Override
	public int regClient(ClientModel model) {		
		return sqlSession.insert("insertClient", model);
	}		
}
