package com.teamfirst.project.dao;

import java.util.List;
import com.teamfirst.project.model.WeatherModel;

public interface WeatherDAO {
	int regWeather(WeatherModel model);
	int delWeather();
	List<WeatherModel> getWeather();
}
