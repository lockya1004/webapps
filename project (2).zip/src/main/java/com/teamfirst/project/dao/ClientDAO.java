package com.teamfirst.project.dao;

import com.teamfirst.project.model.ClientModel;

public interface ClientDAO  {
	int regClient(ClientModel model);
	
}
