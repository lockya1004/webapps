package com.teamfirst.project.service;

import java.sql.SQLException;
import java.util.List;

import com.teamfirst.project.model.JobModel;
import com.teamfirst.project.model.LinguistModel;

public interface LinguistService {
	
	int regLinguist(LinguistModel model) throws SQLException;
	List<LinguistModel> getLinguistList() throws SQLException;
	LinguistModel getLinguistListByNum(int num) throws SQLException;
	LinguistModel getLinguistListById(String id) throws SQLException;
	LinguistModel getLinguistListByCode(int code) throws SQLException;
	int updateLinguist(LinguistModel model) throws SQLException;
	List<JobModel> getJobList() throws SQLException;
	List<LinguistModel> searchLinguist(String keyword) throws SQLException;

/*    int regContent(Map<String, Object> paramMap);   
    int getContentCnt(Map<String, Object> paramMap);     
    List<Board> getContentList(Map<String, Object> paramMap);     
    Board getContentView(Map<String, Object> paramMap);     
    int regReply(Map<String, Object> paramMap);     
    List<BoardReply> getReplyList(Map<String, Object> paramMap);     
    int delReply(Map<String, Object> paramMap);     
    int getBoardCheck(Map<String, Object> paramMap);     
    int delBoard(Map<String, Object> paramMap);*/
}
