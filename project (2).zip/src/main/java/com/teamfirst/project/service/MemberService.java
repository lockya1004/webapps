package com.teamfirst.project.service;
import java.sql.SQLException;

import com.teamfirst.project.model.LoginModel;
import com.teamfirst.project.model.MemberModel;

public interface MemberService {
	MemberModel login(LoginModel loginModel) throws SQLException;
	MemberModel getMemberList(String userid) throws SQLException;
	int conrfirmMember(String userid) throws SQLException;
	int regMember(MemberModel model) throws SQLException;
	int updateMember(MemberModel model) throws SQLException;
	MemberModel checkLoginBefore(String value) throws SQLException;
	MemberModel checkMember(String userid) throws SQLException;
	
//	void of(Connection con, PreparedStatement ps, ResultSet rs);
	
/*    int regContent(Map<String, Object> paramMap);   
    int getContentCnt(Map<String, Object> paramMap);     
    List<Board> getContentList(Map<String, Object> paramMap);     
    Board getContentView(Map<String, Object> paramMap);     
    int regReply(Map<String, Object> paramMap);     
    List<BoardReply> getReplyList(Map<String, Object> paramMap);     
    int delReply(Map<String, Object> paramMap);     
    int getBoardCheck(Map<String, Object> paramMap);     
    int delBoard(Map<String, Object> paramMap);*/
}
