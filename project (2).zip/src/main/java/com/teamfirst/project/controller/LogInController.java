package com.teamfirst.project.controller;

import java.sql.SQLException;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.teamfirst.project.model.LoginModel;
import com.teamfirst.project.model.MemberModel;
import com.teamfirst.project.service.MainService;
import com.teamfirst.project.service.MemberService;
import com.teamfirst.project.service.WeatherService;

@Controller
public class LogInController {

	@Inject
	private MemberService memberService;
	@Inject
	private MainService mainService;
	@Inject
	private WeatherService weatherService;
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginGET(@ModelAttribute("loginModel") LoginModel loginModel) throws SQLException{
			
		return "/member/login";
	}
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public String logOut(HttpSession session, Model model) throws SQLException{
			
		Object object = session.getAttribute("login");
		System.out.println("obj: "+object);
		
		if(object!=null){			
			session.removeAttribute("login");
			session.invalidate();			
		}
		System.out.println("login :"+session.getId());
		model.addAttribute("main", mainService.getNewList());
		model.addAttribute("weatherlist", weatherService.getWeather());

		return "redirect:/"; //"/main";
	}
	
	@RequestMapping(value = "/loginPost", method = RequestMethod.POST)
	public String loginPOST(LoginModel loginModel, HttpSession session, Model model) throws SQLException{
			
		MemberModel memberModel = memberService.login(loginModel);
		
		if(memberModel==null){
			return null;
		} 
		model.addAttribute("memberModel", memberModel);
		
		System.out.println("memberModel: "+memberModel);
		return "/member/loginPost";
	}
	
}
