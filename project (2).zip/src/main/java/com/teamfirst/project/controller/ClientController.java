package com.teamfirst.project.controller;

import java.sql.SQLException;

import javax.inject.Inject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


import com.teamfirst.project.service.ClientService;

@Controller
public class ClientController {

	@Inject
	private ClientService clientService;
	
	@RequestMapping("/client/go.register")
	public String clientRegister(Model model) throws SQLException {
		
		return "client/clientRegister";
	}
	
	@RequestMapping("/client/go.search")
	public String reqList(Model model) throws SQLException {
		
		return "client/clientSearch";
	}
}
