package com.teamfirst.project.controller;

import java.sql.SQLException;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.teamfirst.project.service.LinguistService;

@Controller
public class LinguistController {
	
	@Inject
	private LinguistService linguistProfileService;

	@RequestMapping("/linguist/go.register")
	public String linguistRegister(Model model) throws SQLException {
		
		return "linguist/linguistRegister";
	}
	
	@RequestMapping("/linguist/go.search")
	public String linguistSearch(Model model) throws SQLException {
		
		return "linguist/linguistSearch";
	}
}
