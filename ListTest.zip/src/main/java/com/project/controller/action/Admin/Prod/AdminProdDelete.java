package com.project.controller.action.Admin.Prod;

public class AdminProdDelete {

}
